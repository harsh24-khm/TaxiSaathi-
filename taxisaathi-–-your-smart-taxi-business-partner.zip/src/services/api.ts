import { User, Trip, Expense, DashboardSummary, AIAuditResult, DatabaseStatus } from '../types.js';

const TOKEN_KEY = 'taxisaathi_token';
const USER_KEY = 'taxisaathi_user';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredAuth(token: string, user: User) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearStoredAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): User | null {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data as T;
}

export const api = {
  // Auth
  async register(body: any): Promise<{ token: string; user: User; message: string }> {
    return request('/api/auth/register', { method: 'POST', body: JSON.stringify(body) });
  },

  async login(body: any): Promise<{ token: string; user: User; message: string }> {
    return request('/api/auth/login', { method: 'POST', body: JSON.stringify(body) });
  },

  async demoLogin(): Promise<{ token: string; user: User; message: string }> {
    return request('/api/auth/demo-login', { method: 'POST' });
  },

  async getMe(): Promise<{ user: User }> {
    return request('/api/auth/me');
  },

  async updateProfile(profile: Partial<User>): Promise<{ message: string; user: User }> {
    return request('/api/auth/profile', { method: 'PUT', body: JSON.stringify(profile) });
  },

  async forgotPassword(email: string): Promise<{ message: string; resetToken?: string; resetCode?: string }> {
    return request('/api/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) });
  },

  async resetPassword(payload: any): Promise<{ message: string }> {
    return request('/api/auth/reset-password', { method: 'POST', body: JSON.stringify(payload) });
  },

  // Trips
  async getTrips(filters?: { search?: string; startDate?: string; endDate?: string; paymentMode?: string }): Promise<{ trips: Trip[] }> {
    const params = new URLSearchParams();
    if (filters?.search) params.append('search', filters.search);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    if (filters?.paymentMode) params.append('paymentMode', filters.paymentMode);
    const q = params.toString() ? `?${params.toString()}` : '';
    return request(`/api/trips${q}`);
  },

  async createTrip(tripData: Partial<Trip>): Promise<{ message: string; trip: Trip }> {
    return request('/api/trips', { method: 'POST', body: JSON.stringify(tripData) });
  },

  async updateTrip(id: string, updates: Partial<Trip>): Promise<{ message: string; trip: Trip }> {
    return request(`/api/trips/${id}`, { method: 'PUT', body: JSON.stringify(updates) });
  },

  async deleteTrip(id: string): Promise<{ message: string }> {
    return request(`/api/trips/${id}`, { method: 'DELETE' });
  },

  // Expenses
  async getExpenses(filters?: { category?: string; startDate?: string; endDate?: string }): Promise<{
    expenses: Expense[];
    summary: { totalAmount: number; totalCount: number; categoryTotals: Record<string, number> };
  }> {
    const params = new URLSearchParams();
    if (filters?.category) params.append('category', filters.category);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const q = params.toString() ? `?${params.toString()}` : '';
    return request(`/api/expenses${q}`);
  },

  async createExpense(expenseData: Partial<Expense>): Promise<{ message: string; expense: Expense }> {
    return request('/api/expenses', { method: 'POST', body: JSON.stringify(expenseData) });
  },

  async updateExpense(id: string, updates: Partial<Expense>): Promise<{ message: string; expense: Expense }> {
    return request(`/api/expenses/${id}`, { method: 'PUT', body: JSON.stringify(updates) });
  },

  async deleteExpense(id: string): Promise<{ message: string }> {
    return request(`/api/expenses/${id}`, { method: 'DELETE' });
  },

  // Analytics & Dashboard
  async getDashboardAnalytics(): Promise<DashboardSummary> {
    return request('/api/analytics/dashboard');
  },

  // AI Assistant
  async getAIAudit(): Promise<{ audit: AIAuditResult; source: string }> {
    return request('/api/ai/audit', { method: 'POST' });
  },

  async chatWithAI(message: string, language: string = 'en'): Promise<{ reply: string; source: string }> {
    return request('/api/ai/chat', { method: 'POST', body: JSON.stringify({ message, language }) });
  },

  // Reports
  async getReportSummary(filters?: { period?: string; startDate?: string; endDate?: string }): Promise<any> {
    const params = new URLSearchParams();
    if (filters?.period) params.append('period', filters.period);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    const q = params.toString() ? `?${params.toString()}` : '';
    return request(`/api/reports/summary${q}`);
  },

  // Database status & testing
  async getDatabaseStatus(): Promise<DatabaseStatus> {
    return request('/api/database/status');
  },

  async testMongoDB(uri: string): Promise<{ success: boolean; message?: string; error?: string }> {
    return request('/api/database/test-mongodb', { method: 'POST', body: JSON.stringify({ uri }) });
  }
};
