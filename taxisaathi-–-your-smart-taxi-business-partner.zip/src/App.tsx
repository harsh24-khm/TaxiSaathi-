import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { LandingPage } from './components/landing/LandingPage.js';
import { AuthModal } from './components/auth/AuthModal.js';
import { Header } from './components/common/Header.js';
import { Sidebar, ActiveTab } from './components/common/Sidebar.js';
import { DashboardView } from './components/dashboard/DashboardView.js';
import { TripManager } from './components/trips/TripManager.js';
import { ExpenseManager } from './components/expenses/ExpenseManager.js';
import { AIAssistantView } from './components/ai/AIAssistantView.js';
import { ReportsView } from './components/reports/ReportsView.js';
import { SettingsModal } from './components/settings/SettingsModal.js';
import { api } from './services/api.js';
import { DashboardSummary } from './types.js';

function TaxiSaathiApp() {
  const { user, token, loading: authLoading, demoLogin } = useAuth();

  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [viewMode, setViewMode] = useState<'app' | 'landing'>('app');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authInitialTab, setAuthInitialTab] = useState<'login' | 'register'>('login');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [openTripModalDirectly, setOpenTripModalDirectly] = useState(false);
  const [openExpenseModalDirectly, setOpenExpenseModalDirectly] = useState(false);

  // Dashboard Data & DB status
  const [dashboardData, setDashboardData] = useState<DashboardSummary | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(false);
  const [dbMode, setDbMode] = useState<'mongodb' | 'local'>('local');

  const fetchDashboardData = async () => {
    if (!token) return;
    setLoadingDashboard(true);
    try {
      const data = await api.getDashboardAnalytics();
      setDashboardData(data);
    } catch (err) {
      console.error('Failed to load dashboard:', err);
    } finally {
      setLoadingDashboard(false);
    }
  };

  const checkDbStatus = async () => {
    try {
      const res = await api.getDatabaseStatus();
      setDbMode(res.mode);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    checkDbStatus();
  }, []);

  useEffect(() => {
    if (user && token) {
      fetchDashboardData();
      setViewMode('app');
    } else {
      setViewMode('landing');
    }
  }, [user, token]);

  const handleOpenAuth = (initialTab: 'login' | 'register' = 'login') => {
    setAuthInitialTab(initialTab);
    setIsAuthModalOpen(true);
  };

  const handleDemoLogin = async () => {
    try {
      await demoLogin();
      setViewMode('app');
      setActiveTab('dashboard');
    } catch (err) {
      console.error(err);
    }
  };

  // If initial auth check is ongoing
  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#0B132B] flex flex-col items-center justify-center text-white">
        <div className="w-12 h-12 border-3 border-amber-400 border-t-transparent rounded-full animate-spin mb-4" />
        <h3 className="text-xl font-bold font-heading">
          Taxi<span className="text-amber-400">Saathi</span>
        </h3>
        <p className="text-xs text-slate-400 mt-1">Starting driver business engine...</p>
      </div>
    );
  }

  // If user is unauthenticated OR explicitly chose to preview landing page
  if (!user || viewMode === 'landing') {
    return (
      <>
        {user && (
          <div className="sticky top-0 z-50 bg-amber-400 text-slate-950 px-4 py-2 text-xs font-bold flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span>Logged in as <strong>{user.name}</strong> ({user.vehicleNumber || 'Driver'})</span>
            </div>
            <button
              onClick={() => setViewMode('app')}
              className="px-3 py-1 bg-slate-950 text-white rounded-lg text-xs font-bold hover:bg-slate-900 transition-colors"
            >
              Return to Driver Dashboard →
            </button>
          </div>
        )}
        <LandingPage onOpenAuth={handleOpenAuth} onDemoLogin={handleDemoLogin} />
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          initialTab={authInitialTab}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col">
      {/* Top Header */}
      <Header
        onOpenTripModal={() => {
          setActiveTab('trips');
          setOpenTripModalDirectly(true);
        }}
        onOpenExpenseModal={() => {
          setActiveTab('expenses');
          setOpenExpenseModalDirectly(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onNavigateHome={() => setViewMode('landing')}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        dbMode={dbMode}
      />

      <div className="flex-1 flex">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            setOpenTripModalDirectly(false);
            setOpenExpenseModalDirectly(false);
          }}
          onNavigateHome={() => setViewMode('landing')}
          isOpen={isSidebarOpen}
          onCloseMobile={() => setIsSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 lg:pl-64 transition-all duration-200 min-h-[calc(100vh-4rem)]">
          {activeTab === 'dashboard' && (
            <DashboardView
              summaryData={dashboardData}
              loading={loadingDashboard}
              onOpenTripModal={() => {
                setActiveTab('trips');
                setOpenTripModalDirectly(true);
              }}
              onOpenExpenseModal={() => {
                setActiveTab('expenses');
                setOpenExpenseModalDirectly(true);
              }}
              onSelectTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'trips' && (
            <TripManager
              onRefreshDashboard={fetchDashboardData}
              openAddModalInitially={openTripModalDirectly}
            />
          )}

          {activeTab === 'expenses' && (
            <ExpenseManager
              onRefreshDashboard={fetchDashboardData}
              openAddModalInitially={openExpenseModalDirectly}
            />
          )}

          {activeTab === 'ai' && <AIAssistantView />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'settings' && (
            <div className="p-6">
              <SettingsModal
                isOpen={true}
                onClose={() => setActiveTab('dashboard')}
                onProfileUpdated={fetchDashboardData}
              />
            </div>
          )}
        </main>
      </div>

      {/* Global Settings & Database modal */}
      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          onProfileUpdated={fetchDashboardData}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <TaxiSaathiApp />
    </AuthProvider>
  );
}
