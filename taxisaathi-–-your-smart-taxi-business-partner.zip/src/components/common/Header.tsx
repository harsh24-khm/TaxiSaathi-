import React from 'react';
import {
  Car,
  PlusCircle,
  Fuel,
  Database,
  Menu,
  X,
  Sparkles,
  LogOut,
  Settings as SettingsIcon,
  Globe
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';

interface HeaderProps {
  onOpenTripModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenSettings: () => void;
  onNavigateHome: () => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  dbMode?: 'mongodb' | 'local';
}

export const Header: React.FC<HeaderProps> = ({
  onOpenTripModal,
  onOpenExpenseModal,
  onOpenSettings,
  onNavigateHome,
  onToggleSidebar,
  isSidebarOpen,
  dbMode = 'local'
}) => {
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0B132B]/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-4 sm:px-6 lg:px-8">
      {/* Left: Mobile Toggle & Brand */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden focus:outline-none"
          title="Toggle Navigation"
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div onClick={onNavigateHome} className="flex items-center space-x-2.5 cursor-pointer">
          <div className="w-9 h-9 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md shadow-amber-400/20">
            <Car className="w-5 h-5" />
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center space-x-1.5">
              <span className="text-lg font-black tracking-tight text-white font-heading">
                Taxi<span className="text-amber-400">Saathi</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 bg-amber-400/20 text-amber-300 rounded border border-amber-400/30">
                PRO
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Center: Vehicle & Driver Identity */}
      <div className="hidden md:flex items-center space-x-2.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="font-bold text-white">{user?.name || 'Driver'}</span>
        <span className="text-slate-500">•</span>
        <span className="font-semibold text-amber-300 uppercase">{user?.vehicleNumber || 'CAB REGISTERED'}</span>
        <span className="text-slate-500">•</span>
        <span className="text-slate-400 capitalize">{user?.vehicleType || 'Sedan'} ({user?.fuelType?.toUpperCase() || 'CNG'})</span>
      </div>

      {/* Right: Quick Action Buttons & Status */}
      <div className="flex items-center space-x-2.5">
        {/* Database Status Pill */}
        <button
          onClick={onOpenSettings}
          className="hidden sm:inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors bg-slate-800/80 hover:bg-slate-750 text-slate-300 border-slate-700"
          title="Click to view Database & MongoDB Atlas configuration"
        >
          <Database className={`w-3.5 h-3.5 ${dbMode === 'mongodb' ? 'text-emerald-400' : 'text-amber-400'}`} />
          <span>{dbMode === 'mongodb' ? 'MongoDB Atlas' : 'Local Storage'}</span>
        </button>

        {/* Quick Log Trip */}
        <button
          onClick={onOpenTripModal}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-md shadow-amber-400/20 transition-all transform active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Log Trip</span>
        </button>

        {/* Quick Add Expense */}
        <button
          onClick={onOpenExpenseModal}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 hover:border-slate-600 transition-all transform active:scale-95"
        >
          <Fuel className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Add Expense</span>
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          title="Driver & Database Settings"
        >
          <SettingsIcon className="w-4 h-4" />
        </button>

        {/* Logout */}
        <button
          onClick={logout}
          className="p-2 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-500/10 transition-colors"
          title="Log Out"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
