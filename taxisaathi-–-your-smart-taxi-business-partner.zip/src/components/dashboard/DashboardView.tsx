import React, { useState } from 'react';
import {
  Car,
  TrendingUp,
  Fuel,
  Wallet,
  Gauge,
  PlusCircle,
  Bot,
  FileSpreadsheet,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Sparkles,
  MapPin,
  Clock,
  ChevronRight,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { DashboardSummary } from '../../types.js';
import { useAuth } from '../../context/AuthContext.js';

interface DashboardViewProps {
  summaryData: DashboardSummary | null;
  loading: boolean;
  onOpenTripModal: () => void;
  onOpenExpenseModal: () => void;
  onSelectTab: (tab: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  summaryData,
  loading,
  onOpenTripModal,
  onOpenExpenseModal,
  onSelectTab
}) => {
  const { user } = useAuth();
  const currency = user?.currency || '₹';

  // Graph Metric selector: 'all' | 'revenue' | 'profit' | 'expenses'
  const [chartMetric, setChartMetric] = useState<'all' | 'revenue' | 'profit'>('all');
  const [hoveredPoint, setHoveredPoint] = useState<any | null>(null);

  if (loading || !summaryData) {
    return (
      <div className="p-6 sm:p-8 space-y-6">
        <div className="h-8 w-64 bg-slate-800 rounded animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-28 bg-slate-800/60 rounded-2xl animate-pulse" />
          ))}
        </div>
        <div className="h-72 bg-slate-800/60 rounded-2xl animate-pulse" />
      </div>
    );
  }

  const { summary, dailySeries, recentTrips } = summaryData;

  // Chart scaling calculations
  const maxVal = Math.max(
    ...dailySeries.map(d => Math.max(d.revenue, d.expenses, d.profit, 100)),
    1000
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Welcome & Quick Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-2">
        <div>
          <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Driver Operations Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
            Namaste, {user?.name || 'Driver'}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Here is your live taxi financial summary and profit pulse for today.
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenTripModal}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-md shadow-amber-400/20 transition-all flex items-center space-x-2 transform active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Log New Trip</span>
          </button>

          <button
            onClick={onOpenExpenseModal}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all flex items-center space-x-1.5 transform active:scale-95"
          >
            <Fuel className="w-4 h-4 text-amber-400" />
            <span>+ Fuel / Expense</span>
          </button>

          <button
            onClick={() => onSelectTab('ai')}
            className="px-3.5 py-2.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 font-bold text-xs transition-all flex items-center space-x-1.5"
          >
            <Bot className="w-4 h-4 text-purple-400" />
            <span>Ask AI Saathi</span>
          </button>

          <button
            onClick={() => onSelectTab('reports')}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-300 font-bold text-xs border border-slate-700 transition-all flex items-center space-x-1.5"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Reports</span>
          </button>
        </div>
      </div>

      {/* 6 Key Driver KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Total Trips */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total Trips</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center">
              <Car className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-white font-heading">{summary.totalTrips}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Today: <span className="text-amber-400 font-bold">{summary.today.trips} rides</span>
            </div>
          </div>
        </div>

        {/* Daily Earnings */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Today's Revenue</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-emerald-400 font-heading">
              {currency}{summary.today.earnings.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Net Profit: <span className="text-emerald-300 font-bold">{currency}{summary.today.netProfit.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Monthly Earnings */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">This Month Gross</span>
            <div className="w-8 h-8 rounded-lg bg-amber-400/15 text-amber-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-amber-300 font-heading">
              {currency}{summary.month.earnings.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Take-Home: <span className="text-amber-400 font-bold">{currency}{summary.month.netProfit.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Total Distance */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total Distance</span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/15 text-purple-400 flex items-center justify-center">
              <Gauge className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-white font-heading">
              {summary.totalDistance} <span className="text-xs font-normal text-slate-400">KM</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Today: <span className="text-purple-300 font-bold">{summary.today.distance} KM</span>
            </div>
          </div>
        </div>

        {/* Fuel Expenses */}
        <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Fuel Expenses</span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/15 text-rose-400 flex items-center justify-center">
              <Fuel className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-rose-400 font-heading">
              {currency}{summary.totalFuelExpenses.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Today: <span className="text-rose-300 font-bold">{currency}{summary.today.fuelExpense.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Total Net Profit */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 via-slate-800/90 to-slate-900 border border-amber-400/40 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300">Total Net Profit</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-amber-400 text-slate-950">
              {summary.profitMargin}% Margin
            </span>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-amber-400 font-heading">
              {currency}{summary.totalNetProfit.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-300 mt-0.5">
              Take-home after all costs
            </div>
          </div>
        </div>
      </div>

      {/* AI Saathi Insight Pill */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900/30 via-slate-800/80 to-slate-900/80 border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">AI Saathi Quick Insight</span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 rounded">
                Live Analysis
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Your average return is <strong className="text-amber-400 font-bold">{currency}{summary.kpis.avgFarePerKm}/km</strong>. Morning airport slots (06:00 - 09:30 AM) have shown the highest profit density.
            </p>
          </div>
        </div>

        <button
          onClick={() => onSelectTab('ai')}
          className="px-3.5 py-2 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs transition-colors shrink-0 flex items-center space-x-1"
        >
          <span>Run Business Audit</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Main Graph & Unit Economics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Interactive Earnings Graph */}
        <div className="lg:col-span-8 p-6 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-700/70 gap-3">
            <div>
              <h3 className="text-lg font-bold text-white font-heading">
                Earnings, Expenses & Profit Trend
              </h3>
              <p className="text-xs text-slate-400">
                14-day performance tracking with daily breakdowns
              </p>
            </div>

            {/* Metric Filter Tabs */}
            <div className="flex items-center space-x-1.5 bg-slate-900/80 p-1 rounded-xl border border-slate-700/60 text-xs">
              <button
                onClick={() => setChartMetric('all')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  chartMetric === 'all' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                All Metrics
              </button>
              <button
                onClick={() => setChartMetric('revenue')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  chartMetric === 'revenue' ? 'bg-emerald-500 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Revenue
              </button>
              <button
                onClick={() => setChartMetric('profit')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  chartMetric === 'profit' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                Net Profit
              </button>
            </div>
          </div>

          {/* SVG Visual Graph Container */}
          <div className="mt-6 relative">
            {hoveredPoint && (
              <div className="absolute top-2 right-4 z-10 px-3 py-2 rounded-xl bg-slate-900/95 border border-slate-700 text-xs shadow-xl animate-fadeIn">
                <p className="font-bold text-white">{hoveredPoint.label} ({hoveredPoint.date})</p>
                <div className="flex items-center space-x-3 mt-1">
                  <span className="text-emerald-400 font-semibold">Revenue: {currency}{hoveredPoint.revenue}</span>
                  <span className="text-rose-400 font-semibold">Expense: {currency}{hoveredPoint.expenses}</span>
                  <span className="text-amber-400 font-bold">Profit: {currency}{hoveredPoint.profit}</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Trips: {hoveredPoint.tripsCount} • Distance: {hoveredPoint.distance} km
                </p>
              </div>
            )}

            <div className="h-64 flex items-end justify-between gap-1 sm:gap-2 pt-6 pb-2 border-b border-slate-700/60">
              {dailySeries.map((item, idx) => {
                const revHeight = Math.max(6, Math.min(100, Math.round((item.revenue / maxVal) * 100)));
                const expHeight = Math.max(4, Math.min(100, Math.round((item.expenses / maxVal) * 100)));
                const profitHeight = Math.max(4, Math.min(100, Math.round((Math.max(0, item.profit) / maxVal) * 100)));

                return (
                  <div
                    key={idx}
                    onMouseEnter={() => setHoveredPoint(item)}
                    onMouseLeave={() => setHoveredPoint(null)}
                    className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer"
                  >
                    <div className="w-full flex items-end justify-center space-x-1 h-full">
                      {(chartMetric === 'all' || chartMetric === 'revenue') && (
                        <div
                          style={{ height: `${revHeight}%` }}
                          className="w-1.5 sm:w-2.5 rounded-t bg-emerald-500/80 group-hover:bg-emerald-400 transition-all"
                          title={`Revenue: ${currency}${item.revenue}`}
                        />
                      )}
                      {(chartMetric === 'all') && (
                        <div
                          style={{ height: `${expHeight}%` }}
                          className="w-1.5 sm:w-2 rounded-t bg-rose-500/80 group-hover:bg-rose-400 transition-all"
                          title={`Expenses: ${currency}${item.expenses}`}
                        />
                      )}
                      {(chartMetric === 'all' || chartMetric === 'profit') && (
                        <div
                          style={{ height: `${profitHeight}%` }}
                          className="w-1.5 sm:w-2.5 rounded-t bg-amber-400 group-hover:bg-amber-300 transition-all shadow-sm"
                          title={`Net Profit: ${currency}${item.profit}`}
                        />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-2 truncate w-full text-center group-hover:text-amber-400 font-semibold">
                      {item.label.split(' ')[1] || item.label}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center space-x-6 mt-4 text-xs font-semibold">
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded bg-emerald-500" />
                <span className="text-slate-300">Gross Revenue</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded bg-rose-500" />
                <span className="text-slate-300">Expenses (Fuel & Tolls)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded bg-amber-400" />
                <span className="text-slate-300">Net Take-Home Profit</span>
              </div>
            </div>
          </div>
        </div>

        {/* Unit Economics & Vehicle Health */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md">
            <h3 className="text-base font-bold text-white font-heading mb-1">
              Vehicle Unit Economics
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Crucial ratios for cab profit health
            </p>

            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-700/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Average Fare per KM</span>
                  <div className="text-lg font-bold text-white mt-0.5">
                    {currency}{summary.kpis.avgFarePerKm} <span className="text-xs text-slate-500">/ KM</span>
                  </div>
                </div>
                <span className="px-2 py-1 rounded text-xs font-bold bg-emerald-500/20 text-emerald-400">
                  Healthy
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-700/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Fuel Cost per KM</span>
                  <div className="text-lg font-bold text-rose-400 mt-0.5">
                    {currency}{summary.kpis.fuelCostPerKm} <span className="text-xs text-slate-500">/ KM</span>
                  </div>
                </div>
                <span className="px-2 py-1 rounded text-xs font-bold bg-rose-500/20 text-rose-400">
                  Controlled
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-700/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Net Return per KM</span>
                  <div className="text-lg font-bold text-amber-400 mt-0.5">
                    {currency}{summary.kpis.netReturnPerKm} <span className="text-xs text-slate-500">/ KM</span>
                  </div>
                </div>
                <span className="px-2 py-1 rounded text-xs font-bold bg-amber-400/20 text-amber-300">
                  Take-Home
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-700/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Average Ticket per Trip</span>
                  <div className="text-lg font-bold text-white mt-0.5">
                    {currency}{summary.kpis.avgEarningsPerTrip}
                  </div>
                </div>
                <span className="text-xs text-slate-400">
                  {summary.totalTrips} Total
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Trips Ledger */}
      <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/70">
          <div>
            <h3 className="text-lg font-bold text-white font-heading">
              Recent Trip Records
            </h3>
            <p className="text-xs text-slate-400">
              Last trips logged by your vehicle
            </p>
          </div>

          <button
            onClick={() => onSelectTab('trips')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center space-x-1"
          >
            <span>View All Trips</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {recentTrips.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <Car className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold">No trips logged yet.</p>
            <p className="text-xs text-slate-500 mt-1">Click "+ Log New Trip" above to record your first ride!</p>
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 font-semibold border-b border-slate-700/60 pb-2">
                  <th className="py-2.5 px-3">Date & Time</th>
                  <th className="py-2.5 px-3">Pickup → Destination</th>
                  <th className="py-2.5 px-3">Distance</th>
                  <th className="py-2.5 px-3">Fare Received</th>
                  <th className="py-2.5 px-3">Toll / Comm</th>
                  <th className="py-2.5 px-3">Net Profit</th>
                  <th className="py-2.5 px-3">Payment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {recentTrips.map((trip) => (
                  <tr key={trip.id} className="hover:bg-slate-750 transition-colors">
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap">
                      <div className="font-semibold text-white">{trip.tripDate}</div>
                      <div className="text-[11px] text-slate-500">{trip.tripTime}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white truncate max-w-xs">{trip.pickup}</div>
                      <div className="text-slate-400 truncate max-w-xs text-[11px]">→ {trip.destination}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-300 whitespace-nowrap">
                      {trip.distanceKm} KM
                    </td>
                    <td className="py-3 px-3 font-bold text-white whitespace-nowrap">
                      {currency}{trip.fareReceived}
                    </td>
                    <td className="py-3 px-3 text-rose-400 whitespace-nowrap">
                      -{currency}{(trip.tollCharges + trip.commission + (trip.otherTripExpense || 0))}
                    </td>
                    <td className="py-3 px-3 font-bold text-amber-400 whitespace-nowrap">
                      {currency}{trip.netProfit}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-700 text-slate-300">
                        {trip.paymentMode}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
