import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  User,
  Car,
  Fuel,
  Database,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  ShieldCheck,
  Server
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import { DatabaseStatus } from '../../types.js';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, onProfileUpdated }) => {
  const { user, updateUser } = useAuth();

  // Profile states
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [vehicleNumber, setVehicleNumber] = useState(user?.vehicleNumber || '');
  const [vehicleType, setVehicleType] = useState<any>(user?.vehicleType || 'sedan');
  const [fuelType, setFuelType] = useState<any>(user?.fuelType || 'cng');
  const [currency, setCurrency] = useState(user?.currency || '₹');
  const [city, setCity] = useState(user?.city || 'New Delhi');

  // Database states
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [testUri, setTestUri] = useState('');
  const [testingDb, setTestingDb] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message?: string; error?: string } | null>(null);

  // Tab
  const [tab, setTab] = useState<'profile' | 'database'>('profile');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      setName(user.name);
      setPhone(user.phone || '');
      setVehicleNumber(user.vehicleNumber || '');
      setVehicleType(user.vehicleType || 'sedan');
      setFuelType(user.fuelType || 'cng');
      setCurrency(user.currency || '₹');
      setCity(user.city || 'New Delhi');
    }

    const checkDb = async () => {
      try {
        const s = await api.getDatabaseStatus();
        setDbStatus(s);
      } catch (e) {
        console.error(e);
      }
    };
    checkDb();
  }, [user, isOpen]);

  if (!isOpen) return null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg(null);
    setErr(null);
    try {
      await updateUser({
        name,
        phone,
        vehicleNumber,
        vehicleType,
        fuelType,
        currency,
        city
      });
      setMsg('Profile and vehicle details updated successfully!');
      onProfileUpdated?.();
      setTimeout(() => setMsg(null), 3000);
    } catch (e: any) {
      setErr(e.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleTestMongo = async (e: React.FormEvent) => {
    e.preventDefault();
    setTestingDb(true);
    setTestResult(null);
    try {
      const res = await api.testMongoDB(testUri);
      setTestResult(res);
    } catch (e: any) {
      setTestResult({ success: false, error: e.message || 'Connection failed' });
    } finally {
      setTestingDb(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 text-white my-8 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-black font-heading">Settings & Database</h3>
            <p className="text-xs text-slate-400">Manage vehicle details and MongoDB connections</p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 p-1 bg-slate-800 rounded-xl mb-6 border border-slate-700">
          <button
            onClick={() => setTab('profile')}
            className={`py-2 text-xs font-bold rounded-lg transition-all ${
              tab === 'profile' ? 'bg-amber-400 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Driver & Vehicle Info
          </button>
          <button
            onClick={() => setTab('database')}
            className={`py-2 text-xs font-bold rounded-lg transition-all ${
              tab === 'database' ? 'bg-amber-400 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            MongoDB Atlas Hub
          </button>
        </div>

        {msg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{msg}</span>
          </div>
        )}
        {err && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{err}</span>
          </div>
        )}

        {/* TAB 1: PROFILE */}
        {tab === 'profile' && (
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Full Driver Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Cab Plate Number</label>
                <input
                  type="text"
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white uppercase focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Vehicle Category</label>
                <select
                  value={vehicleType}
                  onChange={(e) => setVehicleType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="sedan">Sedan (Dzire, Etios)</option>
                  <option value="hatchback">Hatchback (WagonR, Tiago)</option>
                  <option value="suv">SUV (Ertiga, Innova)</option>
                  <option value="auto">Auto Rickshaw</option>
                  <option value="other">Other Cab</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Primary Fuel Type</label>
                <select
                  value={fuelType}
                  onChange={(e) => setFuelType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="cng">CNG Gas</option>
                  <option value="diesel">Diesel</option>
                  <option value="petrol">Petrol</option>
                  <option value="ev">Electric (EV)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Currency Symbol</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="₹">₹ (INR - Indian Rupee)</option>
                  <option value="$">$ (USD - Dollar)</option>
                  <option value="€">€ (EUR - Euro)</option>
                  <option value="£">£ (GBP - Pound)</option>
                  <option value="AED">AED (UAE Dirham)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Operating City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center space-x-2"
            >
              {saving ? 'Saving...' : 'Update Driver Profile'}
            </button>
          </form>
        )}

        {/* TAB 2: DATABASE */}
        {tab === 'database' && (
          <div className="space-y-5">
            {/* Current Status Box */}
            <div className="p-4 rounded-xl bg-slate-800 border border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400">Current Storage Backend:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                  dbStatus?.isMongoActive ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                }`}>
                  {dbStatus?.isMongoActive ? 'MongoDB Atlas (Live)' : 'Persistent Storage (Active)'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {dbStatus?.isMongoActive
                  ? 'Connected to your remote MongoDB Atlas cluster. All user, trip, and expense records are securely replicated.'
                  : 'Operating on permanent local database with atomic file persistence. Zero data loss on refresh or reboot.'}
              </p>
            </div>

            {/* Test MongoDB Connection String */}
            <form onSubmit={handleTestMongo} className="space-y-3">
              <label className="block text-xs font-bold text-slate-300">
                Test MongoDB Atlas Connection String
              </label>
              <input
                type="text"
                placeholder="mongodb+srv://username:password@cluster0.mongodb.net/taxisaathi"
                value={testUri}
                onChange={(e) => setTestUri(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />

              <button
                type="submit"
                disabled={testingDb || !testUri.trim()}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs transition-colors disabled:opacity-50"
              >
                {testingDb ? 'Pinging MongoDB Atlas Cluster...' : 'Verify MongoDB Atlas Connection'}
              </button>

              {testResult && (
                <div className={`p-3 rounded-xl text-xs flex items-start space-x-2 ${
                  testResult.success
                    ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
                }`}>
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <span>{testResult.message || testResult.error}</span>
                </div>
              )}
            </form>

            {/* Configuration Guide */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
              <h5 className="font-bold text-amber-400">How to configure MongoDB Atlas in Production:</h5>
              <ol className="list-decimal list-inside space-y-1 text-slate-400">
                <li>Create a free MongoDB Atlas cluster at mongodb.com/cloud/atlas.</li>
                <li>In Network Access, allow your Cloud Run IP or 0.0.0.0/0.</li>
                <li>Copy your connection URI and set <code className="text-amber-300 bg-slate-800 px-1 rounded">MONGODB_URI</code> in your environment variables.</li>
                <li>TaxiSaathi will automatically connect, create collections, and sync!</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
