import React, { useState, useEffect } from 'react';
import {
  Car,
  Search,
  Calendar,
  Filter,
  PlusCircle,
  Edit2,
  Trash2,
  TrendingUp,
  MapPin,
  Clock,
  IndianRupee,
  X,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { Trip } from '../../types.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';

interface TripManagerProps {
  onRefreshDashboard: () => void;
  openAddModalInitially?: boolean;
}

export const TripManager: React.FC<TripManagerProps> = ({ onRefreshDashboard, openAddModalInitially = false }) => {
  const { user } = useAuth();
  const currency = user?.currency || '₹';

  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(openAddModalInitially);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form Fields
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [tripDate, setTripDate] = useState(new Date().toISOString().split('T')[0]);
  const [tripTime, setTripTime] = useState(new Date().toTimeString().substring(0, 5));
  const [distanceKm, setDistanceKm] = useState<number | ''>(15);
  const [fareReceived, setFareReceived] = useState<number | ''>(450);
  const [tollCharges, setTollCharges] = useState<number | ''>(0);
  const [commission, setCommission] = useState<number | ''>(45);
  const [otherTripExpense, setOtherTripExpense] = useState<number | ''>(0);
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'card' | 'wallet' | 'other'>('upi');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Calculated live net profit
  const numFare = Number(fareReceived) || 0;
  const numToll = Number(tollCharges) || 0;
  const numComm = Number(commission) || 0;
  const numOther = Number(otherTripExpense) || 0;
  const liveNetProfit = numFare - (numToll + numComm + numOther);

  const fetchTrips = async () => {
    setLoading(true);
    try {
      let startDate: string | undefined;
      let endDate: string | undefined;
      const today = new Date().toISOString().split('T')[0];

      if (dateFilter === 'today') {
        startDate = today;
        endDate = today;
      } else if (dateFilter === 'yesterday') {
        const y = new Date();
        y.setDate(y.getDate() - 1);
        startDate = y.toISOString().split('T')[0];
        endDate = startDate;
      } else if (dateFilter === '7days') {
        const d = new Date();
        d.setDate(d.getDate() - 7);
        startDate = d.toISOString().split('T')[0];
        endDate = today;
      } else if (dateFilter === 'month') {
        startDate = today.substring(0, 7) + '-01';
        endDate = today;
      } else if (dateFilter === 'custom' && customStart && customEnd) {
        startDate = customStart;
        endDate = customEnd;
      }

      const res = await api.getTrips({
        search,
        startDate,
        endDate,
        paymentMode: paymentFilter !== 'all' ? paymentFilter : undefined
      });
      setTrips(res.trips);
    } catch (err: any) {
      setError(err.message || 'Failed to load trips');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrips();
  }, [search, dateFilter, paymentFilter, customStart, customEnd]);

  const openAddModal = () => {
    setEditingTrip(null);
    setPickup('');
    setDestination('');
    setTripDate(new Date().toISOString().split('T')[0]);
    setTripTime(new Date().toTimeString().substring(0, 5));
    setDistanceKm(15);
    setFareReceived(450);
    setTollCharges(0);
    setCommission(45);
    setOtherTripExpense(0);
    setPaymentMode('upi');
    setNotes('');
    setIsModalOpen(true);
  };

  const openEditModal = (trip: Trip) => {
    setEditingTrip(trip);
    setPickup(trip.pickup);
    setDestination(trip.destination);
    setTripDate(trip.tripDate);
    setTripTime(trip.tripTime);
    setDistanceKm(trip.distanceKm);
    setFareReceived(trip.fareReceived);
    setTollCharges(trip.tollCharges);
    setCommission(trip.commission);
    setOtherTripExpense(trip.otherTripExpense);
    setPaymentMode(trip.paymentMode);
    setNotes(trip.notes || '');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pickup.trim() || !destination.trim() || fareReceived === '') {
      setError('Pickup, destination, and fare are required.');
      return;
    }

    setSubmitting(true);
    setError(null);

    const payload = {
      pickup: pickup.trim(),
      destination: destination.trim(),
      tripDate,
      tripTime,
      distanceKm: Number(distanceKm) || 0,
      fareReceived: Number(fareReceived) || 0,
      tollCharges: Number(tollCharges) || 0,
      commission: Number(commission) || 0,
      otherTripExpense: Number(otherTripExpense) || 0,
      paymentMode,
      notes: notes.trim()
    };

    try {
      if (editingTrip) {
        await api.updateTrip(editingTrip.id, payload);
        setSuccess('Trip record updated successfully!');
      } else {
        await api.createTrip(payload);
        setSuccess('New trip logged successfully!');
      }
      setIsModalOpen(false);
      fetchTrips();
      onRefreshDashboard();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Operation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteTrip(id);
      setDeleteConfirmId(null);
      setSuccess('Trip record removed.');
      fetchTrips();
      onRefreshDashboard();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to delete trip.');
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header & New Trip Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Car className="w-4 h-4" />
            <span>Trip Ledger & Management</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
            Your Logged Rides
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Record every passenger ride, calculate exact net earnings, and filter past records.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center space-x-2 transform active:scale-95 shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ Log New Trip</span>
        </button>
      </div>

      {/* Success / Error notification */}
      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{success}</span>
        </div>
      )}
      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center space-x-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by pickup, destination, or note..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Date Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="7days">Last 7 Days</option>
              <option value="month">This Month</option>
              <option value="custom">Custom Date Range</option>
            </select>
          </div>

          {/* Payment Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
            >
              <option value="all">All Payment Types</option>
              <option value="cash">Cash</option>
              <option value="upi">UPI / QR</option>
              <option value="card">Card POS</option>
              <option value="wallet">App Wallet</option>
            </select>
          </div>
        </div>
      </div>

      {/* Custom Date Range Picker when selected */}
      {dateFilter === 'custom' && (
        <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">From:</span>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-white"
            />
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400">To:</span>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-white"
            />
          </div>
        </div>
      )}

      {/* Trips Table & List */}
      <div className="rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">
            <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs font-semibold">Loading trips ledger...</p>
          </div>
        ) : trips.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Car className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h4 className="text-base font-bold text-white mb-1">No trips matching criteria</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
              Try adjusting your search query, clearing date filters, or log a fresh passenger ride.
            </p>
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs"
            >
              + Log New Trip Now
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/60 text-slate-400 font-bold border-b border-slate-700/80">
                <tr>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Route (Pickup → Drop)</th>
                  <th className="py-3 px-4">Distance</th>
                  <th className="py-3 px-4">Gross Fare</th>
                  <th className="py-3 px-4">Deductions</th>
                  <th className="py-3 px-4">Net Trip Profit</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {trips.map((trip) => {
                  const deductions = trip.tollCharges + trip.commission + (trip.otherTripExpense || 0);
                  return (
                    <tr key={trip.id} className="hover:bg-slate-750 transition-colors">
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="font-bold text-white">{trip.tripDate}</div>
                        <div className="text-[11px] text-slate-400">{trip.tripTime}</div>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="font-bold text-white truncate flex items-center space-x-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                          <span className="truncate">{trip.pickup}</span>
                        </div>
                        <div className="text-slate-300 truncate text-[11px] flex items-center space-x-1.5 mt-0.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                          <span className="truncate">{trip.destination}</span>
                        </div>
                        {trip.notes && (
                          <div className="text-[10px] text-slate-400 italic truncate mt-0.5">
                            Note: {trip.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap font-medium text-slate-300">
                        {trip.distanceKm} KM
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap font-bold text-white text-sm">
                        {currency}{trip.fareReceived}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-rose-400 text-xs">
                        -{currency}{deductions}
                        <div className="text-[10px] text-slate-500">
                          (Tolls: {currency}{trip.tollCharges}, Comm: {currency}{trip.commission})
                        </div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="font-black text-amber-400 text-sm">
                          {currency}{trip.netProfit}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-700 text-slate-200">
                          {trip.paymentMode}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => openEditModal(trip)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
                            title="Edit Trip"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(trip.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                            title="Delete Trip"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm w-full text-white shadow-2xl">
            <h3 className="text-lg font-bold">Delete Trip Record?</h3>
            <p className="text-xs text-slate-400 mt-2">
              Are you sure you want to delete this trip? This will adjust your total earnings and distance.
            </p>
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white"
              >
                Yes, Delete Trip
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Trip Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 text-white my-8 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                <Car className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-black font-heading">
                  {editingTrip ? 'Edit Trip Record' : 'Log New Passenger Trip'}
                </h3>
                <p className="text-xs text-slate-400">Quick 15-second entry for cab drivers</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Pickup & Destination */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Pickup Location *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Airport Terminal 3, Connaught Place"
                    value={pickup}
                    onChange={(e) => setPickup(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Destination *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Cyber City Gurgaon, Noida Sec 62"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Trip Date</label>
                  <input
                    type="date"
                    required
                    value={tripDate}
                    onChange={(e) => setTripDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Time</label>
                  <input
                    type="time"
                    required
                    value={tripTime}
                    onChange={(e) => setTripTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Distance & Fare */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Distance (KM)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    placeholder="22"
                    value={distanceKm}
                    onChange={(e) => setDistanceKm(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Gross Fare Received ({currency}) *</label>
                  <input
                    type="number"
                    min="0"
                    required
                    placeholder="650"
                    value={fareReceived}
                    onChange={(e) => setFareReceived(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Deductions: Toll, Commission, Other */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Toll / Fastag ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    value={tollCharges}
                    onChange={(e) => setTollCharges(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">App Comm ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    value={commission}
                    onChange={(e) => setCommission(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Other Tip/Exp ({currency})</label>
                  <input
                    type="number"
                    value={otherTripExpense}
                    onChange={(e) => setOtherTripExpense(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Payment Mode */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="upi">UPI / QR Code</option>
                    <option value="cash">Cash in Hand</option>
                    <option value="card">Card POS</option>
                    <option value="wallet">Ola/Uber Wallet</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Trip Notes (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. Flight pickup, AC on"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Live Net Profit Preview Badge */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-slate-800 to-slate-800 border border-amber-400/30 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Calculated Net Take-Home</span>
                  <div className="text-xl font-black text-amber-400 font-heading">
                    {currency}{liveNetProfit > 0 ? liveNetProfit : 0}
                  </div>
                </div>
                <div className="text-right text-[11px] text-slate-400">
                  Fare - (Tolls + Comm + Other)
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center space-x-2"
              >
                {submitting ? (
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <span>{editingTrip ? 'Save Changes' : 'Record Trip Record'}</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
