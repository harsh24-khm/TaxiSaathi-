import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  Filter,
  TrendingUp,
  Receipt,
  Car,
  Fuel,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';

export const ReportsView: React.FC = () => {
  const { user } = useAuth();
  const currency = user?.currency || '₹';

  const [period, setPeriod] = useState<string>('month');
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [downloadingCsv, setDownloadingCsv] = useState(false);

  const fetchReport = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      let startDate: string | undefined;
      let endDate: string | undefined;

      if (period === 'day') {
        startDate = today;
        endDate = today;
      } else if (period === 'week') {
        const d = new Date();
        d.setDate(d.getDate() - 7);
        startDate = d.toISOString().split('T')[0];
        endDate = today;
      } else if (period === 'month') {
        startDate = today.substring(0, 7) + '-01';
        endDate = today;
      }

      const res = await api.getReportSummary({ period, startDate, endDate });
      setReportData(res);
    } catch (err) {
      console.error('Failed to generate report summary:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [period]);

  const handleDownloadCsv = (type: 'trips' | 'expenses') => {
    setDownloadingCsv(true);
    const token = localStorage.getItem('taxisaathi_token');
    window.location.href = `/api/reports/export/csv?type=${type}&token=${token || ''}`;
    setTimeout(() => setDownloadingCsv(false), 2000);
  };

  const handlePrintPdf = () => {
    window.print();
  };

  if (loading || !reportData) {
    return (
      <div className="p-8 text-center text-slate-400">
        <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-xs font-semibold">Generating business analytics report...</p>
      </div>
    );
  }

  const { summary, trips, expenses, driver } = reportData;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header with Export & Print Actions (no-print) */}
      <div className="no-print flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-2">
        <div>
          <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Financial Statements & Tax Reporting</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
            Reports & Business Ledger
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Verified financial summaries ready for bank loan verification, tax filing, or fleet audits.
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Period selector */}
          <div className="flex items-center space-x-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs font-bold">
            <button
              onClick={() => setPeriod('day')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                period === 'day' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Daily
            </button>
            <button
              onClick={() => setPeriod('week')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                period === 'week' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Weekly
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                period === 'month' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setPeriod('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                period === 'all' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Time
            </button>
          </div>

          {/* Export CSVs */}
          <button
            onClick={() => handleDownloadCsv('trips')}
            disabled={downloadingCsv}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all flex items-center space-x-1.5"
            title="Download trips ledger as CSV"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Trips CSV</span>
          </button>

          <button
            onClick={() => handleDownloadCsv('expenses')}
            disabled={downloadingCsv}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all flex items-center space-x-1.5"
            title="Download expenses ledger as CSV"
          >
            <Download className="w-4 h-4 text-rose-400" />
            <span>Expenses CSV</span>
          </button>

          {/* Print PDF */}
          <button
            onClick={handlePrintPdf}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-md shadow-amber-400/20 transition-all flex items-center space-x-2"
          >
            <Printer className="w-4 h-4" />
            <span>Print Official PDF</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="printable-report bg-white text-slate-900 rounded-2xl p-6 sm:p-10 shadow-xl border border-slate-200">
        {/* Document Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b-2 border-slate-800 gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center font-black text-xl">
              <Car className="w-7 h-7" />
            </div>
            <div>
              <div className="text-2xl font-black tracking-tight text-slate-950 font-heading">
                Taxi<span className="text-amber-500">Saathi</span> Statement
              </div>
              <p className="text-xs text-slate-600 font-semibold">
                Official Commercial Taxi Operations & Income Ledger
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right text-xs">
            <div className="font-bold text-slate-900 text-sm">
              Statement Period: {period.toUpperCase()}
            </div>
            <div className="text-slate-600 mt-0.5">
              Generated: {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
            <div className="text-[11px] text-emerald-700 font-bold mt-1">
              ✓ Verified Digital Accounting Record
            </div>
          </div>
        </div>

        {/* Driver Profile Metadata */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-slate-200 text-xs">
          <div>
            <span className="text-slate-500 font-medium">Driver Operator:</span>
            <div className="font-bold text-slate-900 text-sm">{driver.name}</div>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Vehicle Registration:</span>
            <div className="font-bold text-slate-900 text-sm uppercase">{driver.vehicleNumber || 'COMMERCIAL CAB'}</div>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Vehicle & Fuel:</span>
            <div className="font-bold text-slate-900 capitalize">{driver.vehicleType} ({driver.fuelType})</div>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Operating City:</span>
            <div className="font-bold text-slate-900">{driver.city || 'NCR Region'}</div>
          </div>
        </div>

        {/* Executive Summary Metrics */}
        <div className="py-6 border-b border-slate-200">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">
            Financial Performance Summary
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-600">Gross Passenger Fares</span>
              <div className="text-xl sm:text-2xl font-black text-slate-950 font-heading mt-1">
                {currency}{summary.totalFare.toLocaleString()}
              </div>
              <span className="text-[11px] text-slate-500">{summary.totalTrips} total trips</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-600">Total Deductions & Fuel</span>
              <div className="text-xl sm:text-2xl font-black text-rose-600 font-heading mt-1">
                {currency}{(summary.totalTolls + summary.totalCommissions + summary.totalExpenses).toLocaleString()}
              </div>
              <span className="text-[11px] text-slate-500">Fuel: {currency}{summary.fuelExpenses}</span>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
              <span className="text-xs text-emerald-800 font-bold">Net Operating Profit</span>
              <div className="text-xl sm:text-2xl font-black text-emerald-700 font-heading mt-1">
                {currency}{summary.netOverallProfit.toLocaleString()}
              </div>
              <span className="text-[11px] text-emerald-800 font-bold">{summary.profitMargin}% Net Margin</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-600">Total Distance Logged</span>
              <div className="text-xl sm:text-2xl font-black text-slate-950 font-heading mt-1">
                {summary.totalDistance} <span className="text-sm font-normal text-slate-500">KM</span>
              </div>
              <span className="text-[11px] text-slate-500">Avg {currency}{summary.avgFarePerKm}/km</span>
            </div>
          </div>
        </div>

        {/* Tabular Trips Section */}
        <div className="py-6 border-b border-slate-200">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Passenger Rides Ledger ({trips.length} Rides)
            </h4>
          </div>

          {trips.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">No trips logged in this timeframe.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-300 text-slate-700 font-bold">
                    <th className="py-2">Date & Time</th>
                    <th className="py-2">Pickup → Destination</th>
                    <th className="py-2">KM</th>
                    <th className="py-2">Gross Fare</th>
                    <th className="py-2">Tolls/Comm</th>
                    <th className="py-2">Net Profit</th>
                    <th className="py-2">Mode</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {trips.slice(0, 20).map((t: any) => (
                    <tr key={t.id}>
                      <td className="py-2 text-slate-600 whitespace-nowrap">{t.tripDate} {t.tripTime}</td>
                      <td className="py-2 font-semibold text-slate-900 max-w-xs truncate">{t.pickup} → {t.destination}</td>
                      <td className="py-2 text-slate-600">{t.distanceKm}</td>
                      <td className="py-2 font-bold text-slate-900">{currency}{t.fareReceived}</td>
                      <td className="py-2 text-rose-600">-{currency}{(t.tollCharges + t.commission + (t.otherTripExpense || 0))}</td>
                      <td className="py-2 font-black text-slate-900">{currency}{t.netProfit}</td>
                      <td className="py-2 text-slate-600 uppercase text-[10px]">{t.paymentMode}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {trips.length > 20 && (
                <p className="text-[11px] text-slate-500 mt-2 italic text-center">
                  Showing first 20 of {trips.length} trips. Use "Export CSV" for the full dataset.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Expenses Ledger Section */}
        <div className="py-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
            Operating Expenses & Maintenance Ledger ({expenses.length} Entries)
          </h4>

          {expenses.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">No expenses recorded in this period.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-300 text-slate-700 font-bold">
                    <th className="py-2">Date</th>
                    <th className="py-2">Category</th>
                    <th className="py-2">Description / Notes</th>
                    <th className="py-2">Odometer</th>
                    <th className="py-2">Amount</th>
                    <th className="py-2">Payment Mode</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {expenses.slice(0, 15).map((e: any) => (
                    <tr key={e.id}>
                      <td className="py-2 text-slate-600 whitespace-nowrap">{e.expenseDate}</td>
                      <td className="py-2 font-bold text-slate-900 capitalize">{e.category.replace('_', ' ')}</td>
                      <td className="py-2 text-slate-600 max-w-xs truncate">{e.notes || '—'}</td>
                      <td className="py-2 text-slate-600 font-mono">{e.odometerReading ? `${e.odometerReading} km` : '—'}</td>
                      <td className="py-2 font-bold text-rose-600">{currency}{e.amount}</td>
                      <td className="py-2 text-slate-600 uppercase text-[10px]">{e.paymentMode || 'cash'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Document Footer */}
        <div className="pt-6 border-t-2 border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            Certified electronic report issued via TaxiSaathi.
          </div>
          <div className="font-semibold text-slate-700">
            TaxiSaathi – Your Smart Taxi Business Partner
          </div>
        </div>
      </div>
    </div>
  );
};
