import React, { useState } from 'react';
import {
  Car,
  TrendingUp,
  Fuel,
  ShieldCheck,
  Bot,
  FileSpreadsheet,
  ArrowRight,
  CheckCircle2,
  Clock,
  Sparkles,
  PhoneCall,
  ChevronDown,
  Calculator,
  Compass,
  Zap,
  Award,
  Users
} from 'lucide-react';

interface LandingPageProps {
  onOpenAuth: (initialTab: 'login' | 'register') => void;
  onDemoLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenAuth, onDemoLogin }) => {
  // Interactive Fare & Profit Calculator preview for drivers
  const [calcFare, setCalcFare] = useState<number>(650);
  const [calcDistance, setCalcDistance] = useState<number>(22);
  const [calcFuelType, setCalcFuelType] = useState<string>('cng');
  const [calcToll, setCalcToll] = useState<number>(50);
  const [calcCommPercent, setCalcCommPercent] = useState<number>(10);

  // Approximate fuel cost per km by fuel type
  const fuelCostPerKmMap: Record<string, number> = {
    cng: 3.2,
    diesel: 6.8,
    petrol: 7.9,
    ev: 1.8
  };

  const estimatedFuelCost = Math.round(calcDistance * (fuelCostPerKmMap[calcFuelType] || 3.5));
  const estimatedCommission = Math.round((calcFare * calcCommPercent) / 100);
  const estimatedNetProfit = calcFare - (calcToll + estimatedCommission + estimatedFuelCost);
  const estimatedProfitMargin = Math.max(0, Math.round((estimatedNetProfit / calcFare) * 100));

  // FAQ Accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Is TaxiSaathi suitable for single independent taxi drivers?',
      a: 'Yes, absolutely! TaxiSaathi was specially created with a simple, high-visibility interface so individual drivers can record a trip in less than 15 seconds from their mobile phone or tablet.'
    },
    {
      q: 'How does the AI Saathi Business Assistant help me make more money?',
      a: 'AI Saathi is powered by Google Gemini AI. It analyzes your actual logged trips and fuel expenses, identifies your most profitable driving hours (like morning airport runs), pinpoints fuel waste, and suggests actionable steps to increase your monthly take-home profit by 20% to 35%.'
    },
    {
      q: 'Can I track both app aggregator rides (Ola/Uber) and private offline bookings?',
      a: 'Yes! You can record any ride—whether from Ola, Uber, Rapido, airport prepaid counter, corporate contract, or private outstation bookings. It accurately tracks platform commissions and extra tolls.'
    },
    {
      q: 'Can I download official income reports for bank car loans or taxes?',
      a: 'Yes! With a single click, you can generate and download comprehensive CSV files and print official PDF financial statements showing your gross earnings, fuel ledger, and net business profit.'
    },
    {
      q: 'Can I connect my own MongoDB Atlas database?',
      a: 'Yes! TaxiSaathi features seamless dual-mode storage. By default, it operates on a permanent persistent store, and allows you to test and connect any MongoDB Atlas cluster anytime from Driver Settings.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col selection:bg-amber-400 selection:text-slate-950">
      {/* Top Navbar */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-[#0B132B]/90 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer">
            <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-400/20 ring-2 ring-amber-300">
              <Car className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-2xl font-black tracking-tight text-white font-heading">
                  Taxi<span className="text-amber-400">Saathi</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  SMART PRO
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">Your Smart Taxi Business Partner</p>
            </div>
          </div>

          {/* Navigation links (desktop) */}
          <nav className="hidden md:flex items-center space-x-8 text-sm font-semibold text-slate-300">
            <a href="#features" className="hover:text-amber-400 transition-colors">Features</a>
            <a href="#calculator" className="hover:text-amber-400 transition-colors">Profit Calculator</a>
            <a href="#how-it-works" className="hover:text-amber-400 transition-colors">How It Works</a>
            <a href="#benefits" className="hover:text-amber-400 transition-colors">Driver Benefits</a>
            <a href="#faq" className="hover:text-amber-400 transition-colors">FAQ</a>
          </nav>

          {/* Action buttons */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onDemoLogin}
              className="hidden sm:inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold border border-slate-700 hover:border-amber-400/50 transition-all shadow-sm"
              title="Test the complete dashboard immediately with realistic sample trips"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>1-Click Demo Driver</span>
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="px-4 py-2 rounded-lg text-sm font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Driver Login
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-md shadow-amber-400/20 hover:shadow-amber-400/30 transition-all flex items-center space-x-1.5"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 overflow-hidden">
        {/* Glow & Taxi theme background accents */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/3 left-10 w-72 h-72 bg-blue-600/10 blur-[100px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Tag badge */}
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-slate-800/80 border border-amber-400/30 text-amber-400 text-xs font-bold mb-6 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span>Built for Independent Drivers & Taxi Fleet Operators</span>
            </div>

            {/* Hero Heading */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-white tracking-tight font-heading leading-tight md:leading-tight">
              Your Journey Towards{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500">
                Smarter Taxi Business
              </span>{' '}
              Starts Here.
            </h1>

            {/* Subtitle */}
            <p className="mt-6 text-lg sm:text-xl text-slate-300 leading-relaxed font-normal max-w-2xl mx-auto">
              TaxiSaathi is an intelligent digital copilot designed to help taxi drivers and cab owners effortlessly record trips, control fuel expenses, prevent losses, and boost net take-home profit with AI-powered coaching.
            </p>

            {/* CTA Buttons */}
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => onOpenAuth('register')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-base shadow-xl shadow-amber-400/25 hover:shadow-amber-400/40 transition-all flex items-center justify-center space-x-2 transform hover:-translate-y-0.5"
              >
                <span>Get Started Free</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={onDemoLogin}
                className="w-full sm:w-auto px-7 py-4 rounded-xl bg-slate-800/90 hover:bg-slate-750 text-white font-bold text-base border border-slate-700 hover:border-amber-400/50 transition-all flex items-center justify-center space-x-2 shadow-sm"
              >
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>Try Demo Driver Account</span>
              </button>

              <a
                href="#calculator"
                className="w-full sm:w-auto px-6 py-4 rounded-xl bg-transparent hover:bg-slate-800/50 text-slate-300 hover:text-white font-semibold text-base transition-colors flex items-center justify-center space-x-1.5"
              >
                <span>Explore Features</span>
                <ChevronDown className="w-4 h-4" />
              </a>
            </div>

            {/* Trust badges */}
            <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-8 text-xs font-semibold text-slate-400">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>100% Free for Drivers</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Works on Any Mobile or PC</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Powered by Gemini AI</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Hindi & English Friendly</span>
              </div>
            </div>
          </div>

          {/* Interactive Live Fare & Profit Simulator Preview */}
          <div id="calculator" className="mt-16 max-w-4xl mx-auto rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-900/90 p-6 sm:p-8 border border-slate-700/80 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 blur-3xl pointer-events-none" />

            <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
              <div>
                <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                  <Calculator className="w-4 h-4" />
                  <span>Interactive Driver Simulator</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white font-heading">
                  See How Much You Actually Take Home Per Ride
                </h3>
                <p className="text-sm text-slate-400 mt-0.5">
                  Gross fare is not your real profit. Test TaxiSaathi's instant net deduction engine:
                </p>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                Live Formula
              </span>
            </div>

            <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Controls */}
              <div className="lg:col-span-7 space-y-5">
                <div>
                  <div className="flex justify-between text-sm font-semibold mb-1.5">
                    <span className="text-slate-300">Ride Gross Fare Received</span>
                    <span className="text-amber-400 font-bold text-base">₹{calcFare}</span>
                  </div>
                  <input
                    type="range"
                    min="150"
                    max="3000"
                    step="50"
                    value={calcFare}
                    onChange={(e) => setCalcFare(Number(e.target.value))}
                    className="w-full accent-amber-400 bg-slate-700 h-2 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                    <span>₹150 (Short ride)</span>
                    <span>₹1,500 (Airport)</span>
                    <span>₹3,000 (Outstation)</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Trip Distance</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={calcDistance}
                        onChange={(e) => setCalcDistance(Math.max(1, Number(e.target.value)))}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-bold text-sm focus:border-amber-400 focus:outline-none"
                      />
                      <span className="absolute right-3 top-2.5 text-xs text-slate-400">KM</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Fuel Type</label>
                    <select
                      value={calcFuelType}
                      onChange={(e) => setCalcFuelType(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold text-sm focus:border-amber-400 focus:outline-none"
                    >
                      <option value="cng">CNG (~₹3.2/km)</option>
                      <option value="diesel">Diesel (~₹6.8/km)</option>
                      <option value="petrol">Petrol (~₹7.9/km)</option>
                      <option value="ev">Electric EV (~₹1.8/km)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Toll / Parking (₹)</label>
                    <input
                      type="number"
                      value={calcToll}
                      onChange={(e) => setCalcToll(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-bold text-sm focus:border-amber-400 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">App Commission (%)</label>
                    <select
                      value={calcCommPercent}
                      onChange={(e) => setCalcCommPercent(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold text-sm focus:border-amber-400 focus:outline-none"
                    >
                      <option value="0">0% (Offline / Direct Client)</option>
                      <option value="10">10% (Low Fee Aggregator)</option>
                      <option value="20">20% (Standard Uber / Ola)</option>
                      <option value="25">25% (Peak Platform Cut)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Result card */}
              <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-[#0B132B] p-6 rounded-xl border border-amber-400/30 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Estimated Net Profit</span>
                  <div className="text-4xl font-black text-amber-400 font-heading mt-1">
                    ₹{estimatedNetProfit > 0 ? estimatedNetProfit : 0}
                  </div>
                  <div className="inline-flex items-center space-x-1.5 mt-2 px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{estimatedProfitMargin}% Net Profit Margin</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Estimated Fuel Burn:</span>
                    <span className="text-rose-400 font-bold">-₹{estimatedFuelCost}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Platform Commission:</span>
                    <span className="text-rose-400 font-bold">-₹{estimatedCommission}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Tolls & Fastag:</span>
                    <span className="text-rose-400 font-bold">-₹{calcToll}</span>
                  </div>
                </div>

                <button
                  onClick={() => onOpenAuth('register')}
                  className="mt-6 w-full py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs transition-colors flex items-center justify-center space-x-1.5"
                >
                  <span>Track All Your Real Rides Free</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Features Grid */}
      <section id="features" className="py-20 bg-slate-900/60 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-400 font-bold text-xs uppercase tracking-wider">Features Overview</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-heading">
              Everything A Modern Taxi Operator Needs
            </h2>
            <p className="text-slate-400 text-sm sm:text-base mt-3">
              No complicated spreadsheets. No messy paper receipts. TaxiSaathi gives you clarity, control, and real profits.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature 1 */}
            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/70 hover:border-amber-400/50 transition-all hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold mb-5 group-hover:bg-amber-400 group-hover:text-slate-950 transition-colors">
                <Car className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">15-Second Trip Logger</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Log pickup, drop, fare, tolls, and commission with instant net profit calculation. Filter by date or search past trips effortlessly.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/70 hover:border-amber-400/50 transition-all hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold mb-5 group-hover:bg-blue-500 group-hover:text-white transition-colors">
                <Fuel className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Fuel & Expense Guard</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Record CNG/diesel refills, engine maintenance, insurance premiums, road permits, and challans to know your exact vehicle cost per km.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/70 hover:border-amber-400/50 transition-all hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold mb-5 group-hover:bg-purple-500 group-hover:text-white transition-colors">
                <Bot className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">AI Saathi Coach</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Integrated with Gemini AI to audit your trips, recommend high-paying driving hours, suggest fuel-saving driving habits, and chat in Hindi & English.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700/70 hover:border-amber-400/50 transition-all hover:-translate-y-1 group">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-5 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-colors">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Instant PDF & CSV Reports</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Download bank-ready income reports, monthly earnings statements, and CSV exports for car loans, fleet accounting, or tax filing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-400 font-bold text-xs uppercase tracking-wider">Simple & Fast</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-heading">
              How TaxiSaathi Works in 3 Easy Steps
            </h2>
            <p className="text-slate-400 text-sm sm:text-base mt-2">
              Designed for drivers on the road. No technical expertise required.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="relative p-8 rounded-2xl bg-slate-800/50 border border-slate-700/80 flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg shadow-amber-400/20 mb-6">
                1
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Set Up Vehicle Profile</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Register with your vehicle registration number, cab type (Sedan, Hatchback, SUV, Auto), and fuel type (CNG, Diesel, EV).
              </p>
            </div>

            {/* Step 2 */}
            <div className="relative p-8 rounded-2xl bg-slate-800/50 border border-slate-700/80 flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg shadow-amber-400/20 mb-6">
                2
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Log Rides & Expenses</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Quickly tap to record rides after passenger drop-offs. Add fuel receipts at the gas pump to track daily vehicle burn accurately.
              </p>
            </div>

            {/* Step 3 */}
            <div className="relative p-8 rounded-2xl bg-slate-800/50 border border-slate-700/80 flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg shadow-amber-400/20 mb-6">
                3
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Maximize Daily Profits</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                View your live daily profit graph, consult AI Saathi for high-demand airport surges, and download monthly bank statements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Driver Benefits Section */}
      <section id="benefits" className="py-20 bg-slate-900/80 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
                <Award className="w-4 h-4" />
                <span>Driver Empowerment</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading leading-tight">
                Stop Guessing. Know Your Real Take-Home Money Every Single Day.
              </h2>
              <p className="text-slate-300 text-base leading-relaxed">
                Most drivers look at gross platform balances and assume they made money—only to discover that fuel, vehicle maintenance, tolls, and hidden commissions ate 60% of their earnings.
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex items-start space-x-3">
                  <div className="p-1 rounded-full bg-emerald-500/20 text-emerald-400 mt-1">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">Eliminate Unprofitable Deadhead Rides</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Learn when and where to wait instead of burning costly fuel cruising empty streets.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="p-1 rounded-full bg-emerald-500/20 text-emerald-400 mt-1">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">Save Up to ₹3,500 Monthly on Fuel</h4>
                    <p className="text-xs text-slate-400 mt-0.5">AI driving efficiency tips tailored specifically to your vehicle's engine and fuel type.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="p-1 rounded-full bg-emerald-500/20 text-emerald-400 mt-1">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">Bank-Approved Income Proof</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Official printable ledger for vehicle refinance, personal loans, or family credit.</p>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-6 py-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center space-x-2"
                >
                  <span>Register Free Driver Account</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Visual highlight badge card */}
            <div className="lg:col-span-6 bg-slate-800/90 rounded-2xl border border-slate-700 p-8 shadow-xl">
              <div className="flex items-center justify-between pb-6 border-b border-slate-700/80">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold">
                    <Car className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">Real Driver Impact Metric</h4>
                    <p className="text-xs text-slate-400">Average Results After 30 Days on TaxiSaathi</p>
                  </div>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                  Verified Data
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700/60">
                  <span className="text-xs text-slate-400 font-medium">Net Income Increase</span>
                  <div className="text-2xl font-black text-emerald-400 mt-1">+26.4%</div>
                  <p className="text-[11px] text-slate-500 mt-1">Higher airport & surge ride share</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700/60">
                  <span className="text-xs text-slate-400 font-medium">Fuel Waste Reduced</span>
                  <div className="text-2xl font-black text-amber-400 mt-1">-18.2%</div>
                  <p className="text-[11px] text-slate-500 mt-1">Fewer empty cruising km</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700/60">
                  <span className="text-xs text-slate-400 font-medium">Daily Logging Time</span>
                  <div className="text-2xl font-black text-blue-400 mt-1">&lt; 2 Mins</div>
                  <p className="text-[11px] text-slate-500 mt-1">Zero clutter, instant mobile inputs</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700/60">
                  <span className="text-xs text-slate-400 font-medium">Driver Rating & Health</span>
                  <div className="text-2xl font-black text-purple-400 mt-1">99.1%</div>
                  <p className="text-[11px] text-slate-500 mt-1">On-time vehicle servicing alerts</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-amber-400 font-bold text-xs uppercase tracking-wider">Driver FAQs</span>
            <h2 className="text-3xl font-extrabold text-white mt-2 font-heading">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              Have questions? We are here to support every taxi driver and operator.
            </p>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl bg-slate-800/60 border border-slate-700/80 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between font-bold text-white text-sm sm:text-base hover:text-amber-400 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-5 h-5 text-amber-400 transition-transform duration-200 shrink-0 ml-4 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-sm text-slate-300 leading-relaxed border-t border-slate-700/50 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-[#070D1F] border-t border-slate-800 pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
            {/* Brand */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
                  <Car className="w-6 h-6" />
                </div>
                <span className="text-2xl font-black text-white font-heading">
                  Taxi<span className="text-amber-400">Saathi</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                TaxiSaathi is an intelligent digital copilot empowering independent cab drivers, taxi business owners, and tourist fleet operators to maximize earnings, reduce vehicle downtime, and operate with financial dignity.
              </p>
              <div className="flex items-center space-x-4 text-xs text-slate-400">
                <span>📍 Made for Indian & Global Taxi Drivers</span>
                <span>•</span>
                <span>⚡ Powered by Google Gemini</span>
              </div>
            </div>

            {/* Quick links */}
            <div>
              <h5 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Quick Navigation</h5>
              <ul className="space-y-2 text-xs text-slate-400">
                <li><a href="#features" className="hover:text-amber-400 transition-colors">Features Overview</a></li>
                <li><a href="#calculator" className="hover:text-amber-400 transition-colors">Fare & Profit Simulator</a></li>
                <li><a href="#how-it-works" className="hover:text-amber-400 transition-colors">How It Works</a></li>
                <li><a href="#benefits" className="hover:text-amber-400 transition-colors">Driver Benefits</a></li>
                <li><a href="#faq" className="hover:text-amber-400 transition-colors">Driver FAQs</a></li>
              </ul>
            </div>

            {/* Contact & Driver Support */}
            <div>
              <h5 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Driver Helpline & Support</h5>
              <div className="space-y-2 text-xs text-slate-400">
                <div className="flex items-center space-x-2">
                  <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                  <span>Support: support@taxisaathi.in</span>
                </div>
                <p className="text-[11px] text-slate-500 pt-1">
                  24/7 technical queries & database assistance for fleet owners.
                </p>
                <div className="pt-2">
                  <button
                    onClick={onDemoLogin}
                    className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold border border-slate-700 transition-colors"
                  >
                    Open Live Demo Driver Portal
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <p>© {new Date().getFullYear()} TaxiSaathi – Your Smart Taxi Business Partner. All rights reserved.</p>
            <div className="flex items-center space-x-6">
              <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
              <span className="hover:text-slate-400 cursor-pointer">Driver Safety Guidelines</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
