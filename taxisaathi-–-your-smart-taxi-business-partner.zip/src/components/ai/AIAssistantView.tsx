import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Clock,
  Fuel,
  Send,
  Languages,
  CheckCircle2,
  RefreshCw,
  HelpCircle,
  Lightbulb,
  ShieldCheck,
  Zap,
  ArrowRight
} from 'lucide-react';
import { AIAuditResult } from '../../types.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AIAssistantView: React.FC = () => {
  const { user } = useAuth();
  const currency = user?.currency || '₹';

  // Audit state
  const [audit, setAudit] = useState<AIAuditResult | null>(null);
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [auditSource, setAuditSource] = useState<string>('');

  // Chat state
  const [language, setLanguage] = useState<'en' | 'hi' | 'hinglish'>('en');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `Namaste ${user?.name || 'Saathi'}! I am TaxiSaathi AI – your personal business partner. I analyze your trip revenues, fuel expenses, and route patterns to help you maximize your daily take-home profit. How can I help you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [sending, setSending] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Quick Prompt Chips
  const promptChips = [
    { label: '💰 How to increase daily profit by 25%?', query: 'Analyze my trip data and tell me step-by-step how I can increase my daily net earnings by 25%.' },
    { label: '⛽ Fuel saving tips for my vehicle', query: `What are the best fuel-saving driving techniques for my ${user?.vehicleType || 'sedan'} running on ${user?.fuelType || 'CNG'}?` },
    { label: '⏰ Best profitable hours & routes', query: 'What are the most profitable working hours and hotspot pickup zones in my city?' },
    { label: '📉 Pinpoint unnecessary expenses', query: 'Where am I bleeding the most money in my taxi operations, and how do I plug the leak?' },
    { label: '✈️ Airport run vs Local city rides', query: 'Is it more profitable to queue at the airport for long rides or do quick short local rides back-to-back?' }
  ];

  const runAudit = async () => {
    setLoadingAudit(true);
    try {
      const res = await api.getAIAudit();
      setAudit(res.audit);
      setAuditSource(res.source);
    } catch (err: any) {
      console.error('Audit failed:', err);
    } finally {
      setLoadingAudit(false);
    }
  };

  useEffect(() => {
    runAudit();
  }, []);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || sending) return;

    const userMsg: Message = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setSending(true);

    try {
      const res = await api.chatWithAI(text, language);
      const aiMsg: Message = {
        id: 'reply_' + Date.now(),
        sender: 'assistant',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      const errorMsg: Message = {
        id: 'err_' + Date.now(),
        sender: 'assistant',
        text: 'Apologies, I encountered an issue analyzing the data. Please try again or rephrase your question.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Powered by Google Gemini 3.8 Flash</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
            AI Saathi – Your Smart Business Coach
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Personalized intelligence to cut wasteful expenses, optimize working hours, and boost profit margins.
          </p>
        </div>

        <button
          onClick={runAudit}
          disabled={loadingAudit}
          className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/20 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 shrink-0"
        >
          <RefreshCw className={`w-4 h-4 ${loadingAudit ? 'animate-spin' : ''}`} />
          <span>{loadingAudit ? 'Analyzing Business...' : 'Re-Run Deep Audit'}</span>
        </button>
      </div>

      {/* Business Audit Summary Section */}
      {loadingAudit ? (
        <div className="p-8 rounded-2xl bg-slate-800/80 border border-purple-500/30 text-center space-y-3">
          <div className="w-12 h-12 border-3 border-purple-400 border-t-transparent rounded-full animate-spin mx-auto" />
          <h4 className="text-base font-bold text-white">Analyzing Your Real Rides & Fuel Ledgers...</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            AI Saathi is calculating your cost-per-km efficiency, deadhead cruising time, and profitable hour windows.
          </p>
        </div>
      ) : audit ? (
        <div className="space-y-6">
          {/* Top Banner Card: Health Score & Headline */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-slate-900 border border-purple-500/40 shadow-xl relative overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md bg-purple-500/20 text-purple-300 text-xs font-bold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Business Health: {audit.overallHealth}</span>
                  {auditSource && <span className="text-[10px] text-slate-400">({auditSource})</span>}
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white font-heading leading-snug">
                  "{audit.headline}"
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {audit.personalizedSummary}
                </p>
              </div>

              {/* Health Score Gauge */}
              <div className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 shrink-0 min-w-[130px]">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Health Score</span>
                <div className="text-4xl font-black text-amber-400 font-heading mt-1">
                  {audit.healthScore}
                  <span className="text-lg text-slate-500 font-normal">/100</span>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold mt-1">Top Tier Driver</span>
              </div>
            </div>
          </div>

          {/* Audit Highlights Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* 1. Profit Boosters */}
            <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md space-y-4">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                <TrendingUp className="w-4 h-4" />
                <span>Ways to Increase Profit</span>
              </div>

              <div className="space-y-3">
                {audit.profitBoosters.map((booster, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-white">{booster.title}</h5>
                      <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 shrink-0 ml-2">
                        {booster.impact}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {booster.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Unnecessary Expenses & Alerts */}
            <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md space-y-4">
              <div className="flex items-center space-x-2 text-rose-400 font-bold text-sm">
                <AlertTriangle className="w-4 h-4" />
                <span>Expense & Fuel Alerts</span>
              </div>

              <div className="space-y-3">
                {audit.expenseAlerts.map((alert, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                      {alert.category}
                    </span>
                    <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                      {alert.message}
                    </p>
                  </div>
                ))}

                <div className="pt-2 border-t border-slate-700/60">
                  <span className="text-xs font-bold text-slate-300">Fuel Saving Habits:</span>
                  <ul className="mt-2 space-y-1.5 text-[11px] text-slate-400 list-disc list-inside">
                    {audit.fuelSavingTips.map((tip, idx) => (
                      <li key={idx} className="leading-relaxed">{tip}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* 3. Profitable Working Hours */}
            <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md space-y-4">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
                <Clock className="w-4 h-4" />
                <span>Recommended Driving Windows</span>
              </div>

              <div className="space-y-3">
                {audit.recommendedHours.map((hour, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{hour.window}</span>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300">
                        {hour.demand}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {hour.reason}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* Interactive AI Chat Section */}
      <div className="rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-xl overflow-hidden flex flex-col h-[580px]">
        {/* Chat Header */}
        <div className="p-4 bg-slate-900/90 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500 text-white flex items-center justify-center font-bold shadow-md shadow-purple-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="text-sm font-bold text-white">Ask AI Saathi (Chat Partner)</h4>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-400">Trained on taxi economics & vehicle fleet operations</p>
            </div>
          </div>

          {/* Language Selector */}
          <div className="flex items-center space-x-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs font-bold">
            <Languages className="w-3.5 h-3.5 text-purple-400 ml-1.5" />
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-0.5 rounded-lg transition-colors ${
                language === 'en' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2 py-0.5 rounded-lg transition-colors ${
                language === 'hi' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              हिंदी
            </button>
            <button
              onClick={() => setLanguage('hinglish')}
              className={`px-2 py-0.5 rounded-lg transition-colors ${
                language === 'hinglish' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Hinglish
            </button>
          </div>
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start space-x-2.5 ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-amber-400 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-900 border border-slate-700/80 text-slate-200 rounded-tl-none whitespace-pre-line'
                }`}
              >
                <div>{msg.text}</div>
                <div
                  className={`text-[10px] mt-1.5 ${
                    msg.sender === 'user' ? 'text-slate-800' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {sending && (
            <div className="flex items-center space-x-2 text-slate-400 text-xs">
              <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-700 text-slate-400 text-xs">
                AI Saathi is thinking...
              </div>
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-slate-900/60 border-t border-slate-800/80 overflow-x-auto flex items-center space-x-2 scrollbar-none">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0 flex items-center space-x-1">
            <Lightbulb className="w-3 h-3 text-amber-400" />
            <span>Try:</span>
          </span>
          {promptChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(chip.query)}
              disabled={sending}
              className="text-xs px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 whitespace-nowrap transition-colors shrink-0"
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-900 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              placeholder={`Ask AI Saathi in ${language === 'hi' ? 'हिंदी' : language === 'hinglish' ? 'Hinglish' : 'English'} (e.g. How to save fuel during traffic?)...`}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || sending}
              className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition-all disabled:opacity-40 disabled:hover:bg-purple-600"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
