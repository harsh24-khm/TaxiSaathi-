import React, { useState, useEffect } from 'react';
import {
  Receipt,
  Fuel,
  Wrench,
  Shield,
  FileText,
  AlertTriangle,
  PlusCircle,
  Calendar,
  Filter,
  Edit2,
  Trash2,
  X,
  Gauge,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Expense } from '../../types.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';

interface ExpenseManagerProps {
  onRefreshDashboard: () => void;
  openAddModalInitially?: boolean;
}

export const ExpenseManager: React.FC<ExpenseManagerProps> = ({ onRefreshDashboard, openAddModalInitially = false }) => {
  const { user } = useAuth();
  const currency = user?.currency || '₹';

  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [summary, setSummary] = useState<{ totalAmount: number; totalCount: number; categoryTotals: Record<string, number> }>({
    totalAmount: 0,
    totalCount: 0,
    categoryTotals: {}
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Filters
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(openAddModalInitially);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form Fields
  const [category, setCategory] = useState<Expense['category']>('fuel');
  const [amount, setAmount] = useState<number | ''>(850);
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [odometerReading, setOdometerReading] = useState<number | ''>(78450);
  const [notes, setNotes] = useState('');
  const [receiptRef, setReceiptRef] = useState('');
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'card' | 'wallet' | 'other'>('upi');
  const [submitting, setSubmitting] = useState(false);

  const fetchExpenses = async () => {
    setLoading(true);
    try {
      let startDate: string | undefined;
      let endDate: string | undefined;
      const today = new Date().toISOString().split('T')[0];

      if (dateFilter === 'today') {
        startDate = today;
        endDate = today;
      } else if (dateFilter === '7days') {
        const d = new Date();
        d.setDate(d.getDate() - 7);
        startDate = d.toISOString().split('T')[0];
        endDate = today;
      } else if (dateFilter === 'month') {
        startDate = today.substring(0, 7) + '-01';
        endDate = today;
      }

      const res = await api.getExpenses({
        category: categoryFilter !== 'all' ? categoryFilter : undefined,
        startDate,
        endDate
      });
      setExpenses(res.expenses);
      setSummary(res.summary);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch expenses.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, [categoryFilter, dateFilter]);

  const openAddModal = () => {
    setEditingExpense(null);
    setCategory('fuel');
    setAmount(850);
    setExpenseDate(new Date().toISOString().split('T')[0]);
    setOdometerReading('');
    setNotes('');
    setReceiptRef('');
    setPaymentMode('upi');
    setIsModalOpen(true);
  };

  const openEditModal = (exp: Expense) => {
    setEditingExpense(exp);
    setCategory(exp.category);
    setAmount(exp.amount);
    setExpenseDate(exp.expenseDate);
    setOdometerReading(exp.odometerReading ?? '');
    setNotes(exp.notes || '');
    setReceiptRef(exp.receiptRef || '');
    setPaymentMode(exp.paymentMode || 'cash');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount === '' || Number(amount) <= 0) {
      setError('Please provide a valid expense amount.');
      return;
    }

    setSubmitting(true);
    setError(null);

    const payload = {
      category,
      amount: Number(amount),
      expenseDate,
      odometerReading: odometerReading !== '' ? Number(odometerReading) : undefined,
      notes: notes.trim(),
      receiptRef: receiptRef.trim(),
      paymentMode
    };

    try {
      if (editingExpense) {
        await api.updateExpense(editingExpense.id, payload);
        setSuccess('Expense record updated.');
      } else {
        await api.createExpense(payload);
        setSuccess('Expense recorded successfully!');
      }
      setIsModalOpen(false);
      fetchExpenses();
      onRefreshDashboard();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Expense operation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteExpense(id);
      setDeleteConfirmId(null);
      setSuccess('Expense record deleted.');
      fetchExpenses();
      onRefreshDashboard();
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to delete expense.');
    }
  };

  const categoryIcons: Record<string, any> = {
    fuel: Fuel,
    maintenance: Wrench,
    insurance: Shield,
    permits: FileText,
    challan_parking: AlertTriangle,
    other: Receipt
  };

  const categoryLabels: Record<string, string> = {
    fuel: 'Fuel (CNG/Diesel/Petrol/EV)',
    maintenance: 'Vehicle Maintenance & Service',
    insurance: 'Insurance Policy',
    permits: 'Permits, Fitness & Road Tax',
    challan_parking: 'Challan & Parking',
    other: 'Other Operating Expenses'
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Fuel className="w-4 h-4" />
            <span>Vehicle Expense Ledger</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
            Operating Expenses & Maintenance
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Log fuel receipts, maintenance repairs, and permits to know your exact operating cost.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-5 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center space-x-2 transform active:scale-95 shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ Record Expense</span>
        </button>
      </div>

      {/* Notifications */}
      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{success}</span>
        </div>
      )}
      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center space-x-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400">Total Expenses</span>
            <div className="text-2xl font-black text-white font-heading mt-1">
              {currency}{summary.totalAmount.toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400">{summary.totalCount} entries</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center font-bold">
            <Receipt className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400">Fuel Total</span>
            <div className="text-2xl font-black text-rose-400 font-heading mt-1">
              {currency}{(summary.categoryTotals.fuel || 0).toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400">Largest daily burn</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center font-bold">
            <Fuel className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400">Maintenance & Servicing</span>
            <div className="text-2xl font-black text-amber-400 font-heading mt-1">
              {currency}{(summary.categoryTotals.maintenance || 0).toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400">Oil, tires, repairs</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-400/15 text-amber-400 flex items-center justify-center font-bold">
            <Wrench className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400">Permits, Tax & Parking</span>
            <div className="text-2xl font-black text-purple-400 font-heading mt-1">
              {currency}{((summary.categoryTotals.permits || 0) + (summary.categoryTotals.challan_parking || 0) + (summary.categoryTotals.insurance || 0)).toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-400">Regulatory fees</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center font-bold">
            <FileText className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Category Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
            >
              <option value="all">All Expense Categories</option>
              <option value="fuel">Fuel Only</option>
              <option value="maintenance">Maintenance & Repairs</option>
              <option value="insurance">Insurance</option>
              <option value="permits">Permits & Road Tax</option>
              <option value="challan_parking">Challans & Parking</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Date Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer"
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="7days">Last 7 Days</option>
              <option value="month">This Month</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-semibold">
          Showing {expenses.length} records • Total: <strong className="text-white">{currency}{summary.totalAmount}</strong>
        </div>
      </div>

      {/* Expense Ledger Table */}
      <div className="rounded-2xl bg-slate-800/80 border border-slate-700/80 shadow-md overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">
            <div className="w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs font-semibold">Loading expense ledger...</p>
          </div>
        ) : expenses.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Receipt className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h4 className="text-base font-bold text-white mb-1">No expenses found</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
              Add your fuel bills, gas refills, or servicing invoices to track real operational deductions.
            </p>
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs"
            >
              + Record Expense
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/60 text-slate-400 font-bold border-b border-slate-700/80">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Description / Notes</th>
                  <th className="py-3 px-4">Odometer (KM)</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/40">
                {expenses.map((item) => {
                  const Icon = categoryIcons[item.category] || Receipt;
                  return (
                    <tr key={item.id} className="hover:bg-slate-750 transition-colors">
                      <td className="py-3.5 px-4 whitespace-nowrap font-semibold text-white">
                        {item.expenseDate}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <div className="w-7 h-7 rounded-lg bg-slate-700/80 flex items-center justify-center text-amber-400">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <span className="font-bold text-white capitalize">
                            {item.category.replace('_', ' ')}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs text-slate-300">
                        <div className="truncate">{item.notes || '—'}</div>
                        {item.receiptRef && (
                          <div className="text-[10px] text-slate-500 font-mono">
                            Ref: {item.receiptRef}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap font-mono text-slate-300">
                        {item.odometerReading ? `${item.odometerReading} KM` : '—'}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap font-black text-rose-400 text-sm">
                        {currency}{item.amount.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-700 text-slate-200">
                          {item.paymentMode || 'cash'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => openEditModal(item)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
                            title="Edit Expense"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                            title="Delete Expense"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm w-full text-white shadow-2xl">
            <h3 className="text-lg font-bold">Delete Expense Record?</h3>
            <p className="text-xs text-slate-400 mt-2">
              Are you sure you want to delete this expense record? This will adjust your total business deductions.
            </p>
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Expense Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 sm:p-8 text-white my-8 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                <Fuel className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-black font-heading">
                  {editingExpense ? 'Edit Expense Record' : 'Record Vehicle Expense'}
                </h3>
                <p className="text-xs text-slate-400">Track fuel, maintenance, or tax costs</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Expense Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400 font-medium"
                >
                  <option value="fuel">Fuel (CNG / Diesel / Petrol / EV)</option>
                  <option value="maintenance">Vehicle Maintenance & Servicing</option>
                  <option value="insurance">Insurance Premium</option>
                  <option value="permits">Permits, Fitness & Road Tax</option>
                  <option value="challan_parking">Challans & Parking Tickets</option>
                  <option value="other">Other Operating Costs</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Amount ({currency}) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    placeholder="850"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-bold focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={expenseDate}
                    onChange={(e) => setExpenseDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Odometer Reading (KM)</label>
                  <input
                    type="number"
                    placeholder="78500"
                    value={odometerReading}
                    onChange={(e) => setOdometerReading(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="upi">UPI / QR Code</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="wallet">Fuel App / Fastag</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Bill / Receipt Reference (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. IGL-PUMP-992, Workshop Inv #412"
                  value={receiptRef}
                  onChange={(e) => setReceiptRef(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Notes / Item Details</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Full cylinder refill at Mathura Road station, or Castrol 5W30 engine oil replacement"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center space-x-2"
              >
                {submitting ? (
                  <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <span>{editingExpense ? 'Update Expense' : 'Save Expense Record'}</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
