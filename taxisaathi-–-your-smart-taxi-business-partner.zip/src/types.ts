export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  vehicleNumber?: string;
  vehicleType?: 'sedan' | 'hatchback' | 'suv' | 'auto' | 'other';
  fuelType?: 'cng' | 'diesel' | 'petrol' | 'ev';
  city?: string;
  currency?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Trip {
  id: string;
  userId: string;
  pickup: string;
  destination: string;
  tripDate: string; // YYYY-MM-DD
  tripTime: string; // HH:MM
  distanceKm: number;
  fareReceived: number;
  tollCharges: number;
  commission: number;
  otherTripExpense: number;
  notes?: string;
  paymentMode: 'cash' | 'upi' | 'card' | 'wallet' | 'other';
  netProfit: number;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  userId: string;
  category: 'fuel' | 'maintenance' | 'insurance' | 'permits' | 'challan_parking' | 'other';
  amount: number;
  expenseDate: string; // YYYY-MM-DD
  odometerReading?: number;
  notes?: string;
  receiptRef?: string;
  paymentMode?: 'cash' | 'upi' | 'card' | 'wallet' | 'other';
  createdAt: string;
  updatedAt: string;
}

export interface DailyGraphPoint {
  date: string;
  label: string;
  revenue: number;
  expenses: number;
  profit: number;
  tripsCount: number;
  distance: number;
}

export interface DashboardSummary {
  summary: {
    totalTrips: number;
    totalDistance: number;
    totalFareReceived: number;
    totalOperationalExpenses: number;
    totalFuelExpenses: number;
    totalNetProfit: number;
    profitMargin: number;
    today: {
      trips: number;
      earnings: number;
      netProfit: number;
      expenses: number;
      fuelExpense: number;
      distance: number;
    };
    month: {
      trips: number;
      earnings: number;
      netProfit: number;
      expenses: number;
      fuelExpense: number;
      distance: number;
    };
    kpis: {
      avgFarePerKm: number;
      avgEarningsPerTrip: number;
      fuelCostPerKm: number;
      netReturnPerKm: number;
    };
  };
  dailySeries: DailyGraphPoint[];
  expenseBreakdown: Record<string, number>;
  paymentModes: Record<string, number>;
  recentTrips: Trip[];
}

export interface ProfitBooster {
  title: string;
  impact: string;
  description: string;
}

export interface ExpenseAlert {
  type: 'warning' | 'info';
  category: string;
  message: string;
}

export interface RecommendedHour {
  window: string;
  demand: string;
  reason: string;
}

export interface AIAuditResult {
  overallHealth: string;
  healthScore: number;
  headline: string;
  profitBoosters: ProfitBooster[];
  expenseAlerts: ExpenseAlert[];
  recommendedHours: RecommendedHour[];
  fuelSavingTips: string[];
  personalizedSummary: string;
}

export interface DatabaseStatus {
  mode: 'mongodb' | 'local';
  isMongoActive: boolean;
  mongoConfigured: boolean;
  localRecordCounts?: {
    users: number | string;
    trips: number | string;
    expenses: number | string;
  };
}
