import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { initDatabase } from './server/db.js';
import { seedDemoDriverIfNeeded } from './server/auth.js';
import authRoutes from './server/routes/authRoutes.js';
import tripRoutes from './server/routes/tripRoutes.js';
import expenseRoutes from './server/routes/expenseRoutes.js';
import analyticsRoutes from './server/routes/analyticsRoutes.js';
import aiRoutes from './server/routes/aiRoutes.js';
import reportRoutes from './server/routes/reportRoutes.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/trips', tripRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/database', reportRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'TaxiSaathi Backend API',
    timestamp: new Date().toISOString()
  });
});

async function startServer() {
  try {
    // Initialize Database
    const dbStatus = await initDatabase();
    console.log(`TaxiSaathi Database initialized in [${dbStatus.mode.toUpperCase()}] mode.`);

    // Seed realistic demo driver for immediate evaluation
    await seedDemoDriverIfNeeded();

    const isProduction = process.env.NODE_ENV === 'production';

    if (!isProduction) {
      // Dev mode: Mount Vite dev middleware
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa'
      });
      app.use(vite.middlewares);
      console.log('⚡ Vite dev middleware mounted');
    } else {
      // Production mode: Serve built assets from dist
      const distPath = path.resolve(__dirname, 'dist');
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }

    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚖 TaxiSaathi server listening on http://0.0.0.0:${PORT}`);
    });
  } catch (error) {
    console.error('Fatal error starting TaxiSaathi server:', error);
    process.exit(1);
  }
}

startServer();
