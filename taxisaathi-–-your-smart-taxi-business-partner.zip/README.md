# TaxiSaathi – Your Smart Taxi Business Partner 🚖

**TaxiSaathi** is a modern, responsive, AI-powered web platform designed specifically for local taxi drivers, independent cab operators, and small taxi fleet businesses to manage daily operations, track passenger rides, manage vehicle operating expenses, and maximize net profits with intelligent AI coaching.

---

## 🌟 Key Features

1. **Interactive Driver Landing Page & Profit Simulator**
   - Professional landing page with taxi theme (Dark Navy `#0B132B`, White, Bright Taxi Yellow `#FACC15`).
   - Live interactive fare & net profit estimator allowing drivers to see real take-home money after fuel, platform commissions, and toll deductions.
   - Comprehensive feature highlights, 3-step onboarding guide, driver benefits, and driver FAQs.

2. **Secure Authentication & Driver Profiles**
   - Driver registration with custom vehicle metadata: registration plate number, cab type (*Sedan, Hatchback, SUV, Auto*), fuel type (*CNG, Diesel, Petrol, EV*), and operating city.
   - Secure bcrypt password hashing and JSON Web Token (JWT) session management.
   - Password reset flow with verification code support.
   - **1-Click Demo Driver Login** (`Rajesh Kumar - DL 01 AB 4321`) for instant evaluation with rich historical trips and fuel entries preloaded.

3. **Driver Operations Dashboard**
   - 6 KPI stat cards: Total Trips, Daily Earnings, Monthly Take-Home, Total KM Driven, Fuel Expenses, and Net Profit Margin %.
   - Interactive 14-day SVG financial trend chart displaying Gross Revenue vs Operating Costs vs Net Profit.
   - Unit Economics metrics: Average fare per KM, fuel cost per KM, and average ride ticket size.
   - Recent trip ledger with instant status indicators.

4. **Trip Management (15-Second Logging)**
   - Record pickup and destination, date & time, distance (KM), and fare received.
   - Log trip-specific deductions: Tolls/Fastag, aggregator commissions (*Ola, Uber, Rapido, Offline*), and other trip expenses.
   - Real-time automatic net profit calculation in the logging modal (`Fare - Tolls - Comm - Other = Net Take-Home`).
   - Search by pickup, destination, and notes.
   - Filter by date range (Today, Yesterday, Last 7 Days, This Month, Custom) and payment method (Cash, UPI, Card, Wallet).

5. **Expense Management**
   - Category tracking: Fuel (*CNG, Diesel, Petrol, EV*), Vehicle Maintenance & Servicing, Insurance, Commercial Permits & Road Tax, Challans & Parking, and Other.
   - Record odometer reading and invoice/receipt references.
   - Category breakdown cards and visual cost distribution.

6. **AI Business Assistant ("AI Saathi")**
   - Powered by **Google Gemini 3.8 Flash** (`@google/genai` on Node.js/Express backend).
   - Deep Business Audit: Generates overall business health score (e.g. 84/100), key profit booster recommendations, high expense & fuel burn warnings, and profitable driving windows.
   - Interactive multi-turn chat assistant with language toggle: **English**, **हिंदी (Hindi)**, and **Hinglish**.
   - Quick prompt suggestion chips for rapid driver interaction on mobile.

7. **Reports & Printable Financial Statements**
   - Summary ledger with Daily, Weekly, Monthly, and All-Time aggregates.
   - **1-Click CSV Exports**: Download `taxisaathi-trips.csv` and `taxisaathi-expenses.csv`.
   - **Print / PDF Official Statement**: Clean bank-grade financial statement with official letterhead, driver credentials, and tabular ledger ready for car loans or tax filing.

8. **Database & Storage Architecture**
   - **MongoDB Atlas Integration**: Official MongoDB client support for remote collections (`users`, `trips`, `expenses`, `reports`).
   - **Seamless Persistent Fallback**: Operates out of the box with zero setup using an on-disk JSON database (`data/taxisaathi_db.json`).
   - In-app MongoDB Atlas connection tester in **Driver Settings**.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide Icons, Modern SVG Charts.
- **Backend**: Node.js, Express.js.
- **AI Engine**: Google Gemini API (`gemini-3.8-flash` via `@google/genai`).
- **Database**: MongoDB Atlas (`mongodb` driver) with local disk persistence fallback.
- **Security**: `bcryptjs` password hashing, `jsonwebtoken` (JWT) driver authentication.

---

## ⚙️ Environment Configuration

Create a `.env` file in the root directory (based on `.env.example`):

```env
# Gemini API Key (Required for AI Saathi; AI Studio injects this automatically)
GEMINI_API_KEY="your-gemini-api-key"

# MongoDB Atlas URI (Optional; if empty, uses persistent local storage)
MONGODB_URI="mongodb+srv://<username>:<password>@cluster0.mongodb.net/taxisaathi?retryWrites=true&w=majority"

# JWT Secret for driver authentication tokens
JWT_SECRET="taxisaathi-driver-portal-super-secret-key-2025"

# Port (Defaults to 3000)
PORT="3000"
```

---

## 🚀 Installation & Running Locally

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start Development Server** (Express backend + Vite client):
   ```bash
   npm run dev
   ```
   Open your browser at `http://localhost:3000`.

3. **Build for Production**:
   ```bash
   npm run build
   ```

4. **Run Production Server**:
   ```bash
   npm start
   ```

---

## ☁️ Deployment Instructions

1. **Google Cloud Run / Container Deployment**:
   - The application has a full-stack Express server in `server.ts` that serves both API routes and built client static files from `dist`.
   - Ensure `npm run build` is executed before starting with `npm start`.
   - Set environment variables `GEMINI_API_KEY` and `MONGODB_URI` in the Cloud Run configuration.
