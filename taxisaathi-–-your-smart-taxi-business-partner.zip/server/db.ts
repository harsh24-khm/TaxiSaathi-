import fs from 'fs';
import path from 'path';
import { MongoClient, Db, Collection } from 'mongodb';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  phone?: string;
  vehicleNumber?: string;
  vehicleType?: 'sedan' | 'hatchback' | 'suv' | 'auto' | 'other';
  fuelType?: 'cng' | 'diesel' | 'petrol' | 'ev';
  city?: string;
  currency?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Trip {
  id: string;
  userId: string;
  pickup: string;
  destination: string;
  tripDate: string; // YYYY-MM-DD
  tripTime: string; // HH:MM
  distanceKm: number;
  fareReceived: number;
  tollCharges: number;
  commission: number;
  otherTripExpense: number;
  notes?: string;
  paymentMode: 'cash' | 'upi' | 'card' | 'wallet' | 'other';
  netProfit: number;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  userId: string;
  category: 'fuel' | 'maintenance' | 'insurance' | 'permits' | 'challan_parking' | 'other';
  amount: number;
  expenseDate: string; // YYYY-MM-DD
  odometerReading?: number;
  notes?: string;
  receiptRef?: string;
  paymentMode?: 'cash' | 'upi' | 'card' | 'wallet' | 'other';
  createdAt: string;
  updatedAt: string;
}

export interface ReportRecord {
  id: string;
  userId: string;
  reportType: 'daily' | 'weekly' | 'monthly' | 'custom';
  periodStart: string;
  periodEnd: string;
  summaryData: any;
  generatedAt: string;
}

interface LocalDatabase {
  users: User[];
  trips: Trip[];
  expenses: Expense[];
  reports: ReportRecord[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const LOCAL_DB_FILE = path.join(DATA_DIR, 'taxisaathi_db.json');

// Memory cache for fast reads, synchronized to file
let localDbCache: LocalDatabase = {
  users: [],
  trips: [],
  expenses: [],
  reports: []
};

let mongoClient: MongoClient | null = null;
let mongoDb: Db | null = null;
let isMongoActive = false;

// Initialize storage directory and local database
function ensureLocalDb() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (fs.existsSync(LOCAL_DB_FILE)) {
    try {
      const raw = fs.readFileSync(LOCAL_DB_FILE, 'utf-8');
      localDbCache = JSON.parse(raw);
      if (!localDbCache.users) localDbCache.users = [];
      if (!localDbCache.trips) localDbCache.trips = [];
      if (!localDbCache.expenses) localDbCache.expenses = [];
      if (!localDbCache.reports) localDbCache.reports = [];
    } catch (e) {
      console.error('Error reading local DB, initializing fresh:', e);
      persistLocalDb();
    }
  } else {
    persistLocalDb();
  }
}

function persistLocalDb() {
  try {
    fs.writeFileSync(LOCAL_DB_FILE, JSON.stringify(localDbCache, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write local database file:', err);
  }
}

export async function initDatabase(): Promise<{ mode: 'mongodb' | 'local'; connected: boolean }> {
  ensureLocalDb();

  const mongoUri = process.env.MONGODB_URI;
  if (mongoUri && mongoUri.trim().startsWith('mongodb')) {
    try {
      console.log('Attempting MongoDB connection to configured URI...');
      mongoClient = new MongoClient(mongoUri, {
        serverSelectionTimeoutMS: 5000,
        connectTimeoutMS: 5000
      });
      await mongoClient.connect();
      mongoDb = mongoClient.db('taxisaathi');
      isMongoActive = true;
      console.log('✅ Connected successfully to MongoDB Atlas database: taxisaathi');

      // Create indexes if needed
      await mongoDb.collection('users').createIndex({ email: 1 }, { unique: true });
      await mongoDb.collection('trips').createIndex({ userId: 1, tripDate: -1 });
      await mongoDb.collection('expenses').createIndex({ userId: 1, expenseDate: -1 });

      return { mode: 'mongodb', connected: true };
    } catch (err: any) {
      console.warn('⚠️ MongoDB connection failed, falling back to permanent local store:', err.message);
      isMongoActive = false;
      return { mode: 'local', connected: false };
    }
  }

  console.log('ℹ️ Running in persistent local JSON store mode (MongoDB URI not configured). Permanent on-disk persistence active.');
  return { mode: 'local', connected: false };
}

export function getDatabaseStatus() {
  return {
    mode: isMongoActive ? 'mongodb' : 'local',
    isMongoActive,
    mongoConfigured: !!(process.env.MONGODB_URI && process.env.MONGODB_URI.trim().length > 0),
    localRecordCounts: {
      users: isMongoActive ? 'Synced with Mongo' : localDbCache.users.length,
      trips: isMongoActive ? 'Synced with Mongo' : localDbCache.trips.length,
      expenses: isMongoActive ? 'Synced with Mongo' : localDbCache.expenses.length,
    }
  };
}

// ---------------- USER OPERATIONS ----------------
export async function findUserByEmail(email: string): Promise<User | null> {
  const normEmail = email.toLowerCase().trim();
  if (isMongoActive && mongoDb) {
    const doc = await mongoDb.collection<User>('users').findOne({ email: normEmail });
    return doc;
  }
  return localDbCache.users.find(u => u.email.toLowerCase() === normEmail) || null;
}

export async function findUserById(id: string): Promise<User | null> {
  if (isMongoActive && mongoDb) {
    const doc = await mongoDb.collection<User>('users').findOne({ id });
    return doc;
  }
  return localDbCache.users.find(u => u.id === id) || null;
}

export async function createUser(userData: User): Promise<User> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('users').insertOne(userData as any);
  }
  // Keep local cache updated
  const exists = localDbCache.users.findIndex(u => u.id === userData.id);
  if (exists >= 0) {
    localDbCache.users[exists] = userData;
  } else {
    localDbCache.users.push(userData);
  }
  persistLocalDb();
  return userData;
}

export async function updateUser(id: string, updates: Partial<User>): Promise<User | null> {
  const updatedAt = new Date().toISOString();
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('users').updateOne({ id }, { $set: { ...updates, updatedAt } });
  }

  const idx = localDbCache.users.findIndex(u => u.id === id);
  if (idx >= 0) {
    localDbCache.users[idx] = { ...localDbCache.users[idx], ...updates, updatedAt };
    persistLocalDb();
    return localDbCache.users[idx];
  }
  return null;
}

// ---------------- TRIP OPERATIONS ----------------
export async function getTripsByUserId(userId: string, filters?: { search?: string; startDate?: string; endDate?: string; paymentMode?: string }): Promise<Trip[]> {
  let trips: Trip[] = [];

  if (isMongoActive && mongoDb) {
    const query: any = { userId };
    if (filters?.startDate && filters?.endDate) {
      query.tripDate = { $gte: filters.startDate, $lte: filters.endDate };
    } else if (filters?.startDate) {
      query.tripDate = { $gte: filters.startDate };
    } else if (filters?.endDate) {
      query.tripDate = { $lte: filters.endDate };
    }
    if (filters?.paymentMode && filters.paymentMode !== 'all') {
      query.paymentMode = filters.paymentMode;
    }
    trips = await mongoDb.collection<Trip>('trips').find(query).sort({ tripDate: -1, tripTime: -1 }).toArray();
  } else {
    trips = localDbCache.trips.filter(t => t.userId === userId);

    if (filters?.startDate) {
      trips = trips.filter(t => t.tripDate >= filters.startDate!);
    }
    if (filters?.endDate) {
      trips = trips.filter(t => t.tripDate <= filters.endDate!);
    }
    if (filters?.paymentMode && filters.paymentMode !== 'all') {
      trips = trips.filter(t => t.paymentMode === filters.paymentMode);
    }

    trips.sort((a, b) => {
      const dateCmp = b.tripDate.localeCompare(a.tripDate);
      if (dateCmp !== 0) return dateCmp;
      return (b.tripTime || '').localeCompare(a.tripTime || '');
    });
  }

  if (filters?.search && filters.search.trim()) {
    const q = filters.search.toLowerCase().trim();
    trips = trips.filter(t =>
      t.pickup.toLowerCase().includes(q) ||
      t.destination.toLowerCase().includes(q) ||
      (t.notes && t.notes.toLowerCase().includes(q))
    );
  }

  return trips;
}

export async function createTrip(tripData: Trip): Promise<Trip> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('trips').insertOne(tripData as any);
  }
  localDbCache.trips.unshift(tripData);
  persistLocalDb();
  return tripData;
}

export async function updateTrip(id: string, userId: string, updates: Partial<Trip>): Promise<Trip | null> {
  const updatedAt = new Date().toISOString();
  if (isMongoActive && mongoDb) {
    const res = await mongoDb.collection('trips').findOneAndUpdate(
      { id, userId },
      { $set: { ...updates, updatedAt } },
      { returnDocument: 'after' }
    );
    if (!res) return null;
  }

  const idx = localDbCache.trips.findIndex(t => t.id === id && t.userId === userId);
  if (idx >= 0) {
    localDbCache.trips[idx] = { ...localDbCache.trips[idx], ...updates, updatedAt };
    persistLocalDb();
    return localDbCache.trips[idx];
  }
  return null;
}

export async function deleteTrip(id: string, userId: string): Promise<boolean> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('trips').deleteOne({ id, userId });
  }
  const idx = localDbCache.trips.findIndex(t => t.id === id && t.userId === userId);
  if (idx >= 0) {
    localDbCache.trips.splice(idx, 1);
    persistLocalDb();
    return true;
  }
  return false;
}

// ---------------- EXPENSE OPERATIONS ----------------
export async function getExpensesByUserId(userId: string, filters?: { category?: string; startDate?: string; endDate?: string }): Promise<Expense[]> {
  let expenses: Expense[] = [];

  if (isMongoActive && mongoDb) {
    const query: any = { userId };
    if (filters?.category && filters.category !== 'all') {
      query.category = filters.category;
    }
    if (filters?.startDate && filters?.endDate) {
      query.expenseDate = { $gte: filters.startDate, $lte: filters.endDate };
    } else if (filters?.startDate) {
      query.expenseDate = { $gte: filters.startDate };
    } else if (filters?.endDate) {
      query.expenseDate = { $lte: filters.endDate };
    }
    expenses = await mongoDb.collection<Expense>('expenses').find(query).sort({ expenseDate: -1 }).toArray();
  } else {
    expenses = localDbCache.expenses.filter(e => e.userId === userId);

    if (filters?.category && filters.category !== 'all') {
      expenses = expenses.filter(e => e.category === filters.category);
    }
    if (filters?.startDate) {
      expenses = expenses.filter(e => e.expenseDate >= filters.startDate!);
    }
    if (filters?.endDate) {
      expenses = expenses.filter(e => e.expenseDate <= filters.endDate!);
    }

    expenses.sort((a, b) => b.expenseDate.localeCompare(a.expenseDate));
  }

  return expenses;
}

export async function createExpense(expenseData: Expense): Promise<Expense> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('expenses').insertOne(expenseData as any);
  }
  localDbCache.expenses.unshift(expenseData);
  persistLocalDb();
  return expenseData;
}

export async function updateExpense(id: string, userId: string, updates: Partial<Expense>): Promise<Expense | null> {
  const updatedAt = new Date().toISOString();
  if (isMongoActive && mongoDb) {
    const res = await mongoDb.collection('expenses').findOneAndUpdate(
      { id, userId },
      { $set: { ...updates, updatedAt } },
      { returnDocument: 'after' }
    );
    if (!res) return null;
  }

  const idx = localDbCache.expenses.findIndex(e => e.id === id && e.userId === userId);
  if (idx >= 0) {
    localDbCache.expenses[idx] = { ...localDbCache.expenses[idx], ...updates, updatedAt };
    persistLocalDb();
    return localDbCache.expenses[idx];
  }
  return null;
}

export async function deleteExpense(id: string, userId: string): Promise<boolean> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('expenses').deleteOne({ id, userId });
  }
  const idx = localDbCache.expenses.findIndex(e => e.id === id && e.userId === userId);
  if (idx >= 0) {
    localDbCache.expenses.splice(idx, 1);
    persistLocalDb();
    return true;
  }
  return false;
}

// ---------------- REPORTS OPERATIONS ----------------
export async function saveReport(reportData: ReportRecord): Promise<ReportRecord> {
  if (isMongoActive && mongoDb) {
    await mongoDb.collection('reports').insertOne(reportData as any);
  }
  localDbCache.reports.unshift(reportData);
  persistLocalDb();
  return reportData;
}

export async function getReportsByUserId(userId: string): Promise<ReportRecord[]> {
  if (isMongoActive && mongoDb) {
    return await mongoDb.collection<ReportRecord>('reports').find({ userId }).sort({ generatedAt: -1 }).toArray();
  }
  return localDbCache.reports.filter(r => r.userId === userId);
}
