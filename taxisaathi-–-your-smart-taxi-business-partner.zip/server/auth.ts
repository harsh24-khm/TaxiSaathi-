import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { User, findUserById, createUser, findUserByEmail, createTrip, createExpense } from './db.js';

const JWT_SECRET = process.env.JWT_SECRET || 'taxisaathi-driver-portal-super-secret-key-2025';

export interface AuthRequest extends Request {
  user?: User;
}

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(user: User): string {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      name: user.name
    },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
}

export async function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; email: string };
    const user = await findUserById(decoded.id);

    if (!user) {
      return res.status(401).json({ error: 'User account no longer exists.' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired session token. Please log in again.' });
  }
}

// Seed a rich realistic demo driver profile for immediate hands-on testing
export async function seedDemoDriverIfNeeded() {
  const demoEmail = 'rajesh.kumar@taxisaathi.in';
  let demoUser = await findUserByEmail(demoEmail);

  if (!demoUser) {
    const passwordHash = await hashPassword('taxisaathi123');
    demoUser = {
      id: 'demo-driver-rajesh-001',
      name: 'Rajesh Kumar',
      email: demoEmail,
      passwordHash,
      phone: '+91 98765 43210',
      vehicleNumber: 'DL 01 AB 4321',
      vehicleType: 'sedan',
      fuelType: 'cng',
      city: 'New Delhi',
      currency: '₹',
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date().toISOString()
    };
    await createUser(demoUser);

    const today = new Date();
    const getDateStr = (daysAgo: number) => {
      const d = new Date(today);
      d.setDate(d.getDate() - daysAgo);
      return d.toISOString().split('T')[0];
    };

    // Realistic trips over the last 14 days
    const demoTrips = [
      {
        pickup: 'Indira Gandhi International Airport T3',
        destination: 'Connaught Place, Central Delhi',
        daysAgo: 0,
        time: '08:30',
        distance: 22,
        fare: 650,
        toll: 50,
        comm: 70,
        other: 0,
        mode: 'upi',
        notes: 'Morning airport run, smooth traffic'
      },
      {
        pickup: 'Cyber Hub, DLF Phase 2, Gurgaon',
        destination: 'Noida Sector 62',
        daysAgo: 0,
        time: '11:15',
        distance: 38,
        fare: 1100,
        toll: 100,
        comm: 110,
        other: 20,
        mode: 'cash',
        notes: 'Corporate client, AC full blast'
      },
      {
        pickup: 'South Extension Part 2',
        destination: 'New Delhi Railway Station (Paharganj side)',
        daysAgo: 0,
        time: '15:45',
        distance: 14,
        fare: 420,
        toll: 0,
        comm: 45,
        other: 0,
        mode: 'upi',
        notes: 'Heavy luggage, tipped well'
      },
      {
        pickup: 'Saket Select Citywalk',
        destination: 'Vasant Kunj Promenade Mall',
        daysAgo: 1,
        time: '19:30',
        distance: 11,
        fare: 350,
        toll: 0,
        comm: 35,
        other: 0,
        mode: 'card',
        notes: 'Evening mall shuttle'
      },
      {
        pickup: 'Rohini Sector 14',
        destination: 'Karol Bagh Market',
        daysAgo: 1,
        time: '14:00',
        distance: 19,
        fare: 540,
        toll: 0,
        comm: 55,
        other: 10,
        mode: 'cash',
        notes: 'Family shopping trip'
      },
      {
        pickup: 'Delhi Airport Terminal 1',
        destination: 'Greater Kailash 1',
        daysAgo: 2,
        time: '07:15',
        distance: 18,
        fare: 580,
        toll: 30,
        comm: 60,
        other: 0,
        mode: 'upi',
        notes: 'Early morning flight pickup'
      },
      {
        pickup: 'Khan Market',
        destination: 'Dwarka Expressway Sector 109',
        daysAgo: 2,
        time: '18:10',
        distance: 34,
        fare: 980,
        toll: 80,
        comm: 100,
        other: 0,
        mode: 'upi',
        notes: 'Long haul ride'
      },
      {
        pickup: 'Chandni Chowk',
        destination: 'Anand Vihar ISBT',
        daysAgo: 3,
        time: '10:00',
        distance: 15,
        fare: 440,
        toll: 0,
        comm: 45,
        other: 0,
        mode: 'cash',
        notes: 'Station drop-off'
      },
      {
        pickup: 'Hauz Khas Village',
        destination: 'Gurgaon Golf Course Road',
        daysAgo: 4,
        time: '21:30',
        distance: 26,
        fare: 820,
        toll: 40,
        comm: 80,
        other: 0,
        mode: 'upi',
        notes: 'Night surge pricing ride'
      },
      {
        pickup: 'Lajpat Nagar Central Market',
        destination: 'Delhi Cantonment',
        daysAgo: 5,
        time: '12:45',
        distance: 17,
        fare: 490,
        toll: 0,
        comm: 50,
        other: 0,
        mode: 'wallet',
        notes: 'Army area drop'
      },
      {
        pickup: 'IGI Airport T3',
        destination: 'Faridabad Sector 15',
        daysAgo: 6,
        time: '23:15',
        distance: 42,
        fare: 1350,
        toll: 120,
        comm: 135,
        other: 30,
        mode: 'upi',
        notes: 'Late night interstate pickup'
      },
      {
        pickup: 'Civil Lines',
        destination: 'Connaught Place',
        daysAgo: 7,
        time: '09:00',
        distance: 9,
        fare: 280,
        toll: 0,
        comm: 30,
        other: 0,
        mode: 'cash',
        notes: 'Quick morning commute'
      }
    ];

    for (let i = 0; i < demoTrips.length; i++) {
      const dt = demoTrips[i];
      const netProfit = dt.fare - (dt.toll + dt.comm + dt.other);
      await createTrip({
        id: `trip-demo-${i + 1}`,
        userId: demoUser.id,
        pickup: dt.pickup,
        destination: dt.destination,
        tripDate: getDateStr(dt.daysAgo),
        tripTime: dt.time,
        distanceKm: dt.distance,
        fareReceived: dt.fare,
        tollCharges: dt.toll,
        commission: dt.comm,
        otherTripExpense: dt.other,
        notes: dt.notes,
        paymentMode: dt.mode as any,
        netProfit,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }

    // Realistic expenses
    const demoExpenses = [
      {
        category: 'fuel',
        amount: 850,
        daysAgo: 0,
        odometer: 78420,
        notes: 'CNG full tank fill at IGL station Mathura Road',
        mode: 'upi'
      },
      {
        category: 'challan_parking',
        amount: 120,
        daysAgo: 0,
        odometer: 78390,
        notes: 'Airport commercial lane multi-level parking ticket',
        mode: 'cash'
      },
      {
        category: 'fuel',
        amount: 920,
        daysAgo: 2,
        odometer: 78150,
        notes: 'CNG gas refill',
        mode: 'upi'
      },
      {
        category: 'maintenance',
        amount: 1450,
        daysAgo: 4,
        odometer: 77900,
        notes: 'Engine oil top-up, air filter cleaned, windshield wiper replacement',
        mode: 'upi'
      },
      {
        category: 'fuel',
        amount: 880,
        daysAgo: 5,
        odometer: 77600,
        notes: 'CNG gas fill-up',
        mode: 'upi'
      },
      {
        category: 'permits',
        amount: 600,
        daysAgo: 10,
        odometer: 77100,
        notes: 'State border entry permit fee (NCR permit)',
        mode: 'cash'
      },
      {
        category: 'maintenance',
        amount: 350,
        daysAgo: 12,
        odometer: 76800,
        notes: 'Full vehicle exterior wash and interior vacuuming',
        mode: 'cash'
      }
    ];

    for (let j = 0; j < demoExpenses.length; j++) {
      const de = demoExpenses[j];
      await createExpense({
        id: `exp-demo-${j + 1}`,
        userId: demoUser.id,
        category: de.category as any,
        amount: de.amount,
        expenseDate: getDateStr(de.daysAgo),
        odometerReading: de.odometer,
        notes: de.notes,
        paymentMode: de.mode as any,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }

    console.log('✅ Demo driver account seeded successfully: rajesh.kumar@taxisaathi.in');
  }
}
