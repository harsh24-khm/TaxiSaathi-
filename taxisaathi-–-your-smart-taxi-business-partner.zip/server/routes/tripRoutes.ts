import { Router, Response } from 'express';
import {
  getTripsByUserId,
  createTrip,
  updateTrip,
  deleteTrip,
  Trip
} from '../db.js';
import { authenticateToken, AuthRequest } from '../auth.js';

const router = Router();

// Apply auth to all trip routes
router.use(authenticateToken);

// GET /api/trips - List trips with search and date filters
router.get('/', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { search, startDate, endDate, paymentMode } = req.query as {
      search?: string;
      startDate?: string;
      endDate?: string;
      paymentMode?: string;
    };

    const trips = await getTripsByUserId(userId, {
      search,
      startDate,
      endDate,
      paymentMode
    });

    return res.json({ trips });
  } catch (err: any) {
    console.error('Fetch trips error:', err);
    return res.status(500).json({ error: 'Failed to retrieve trips: ' + err.message });
  }
});

// POST /api/trips - Add a new trip
router.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const {
      pickup,
      destination,
      tripDate,
      tripTime,
      distanceKm,
      fareReceived,
      tollCharges,
      commission,
      otherTripExpense,
      notes,
      paymentMode
    } = req.body;

    if (!pickup || !destination) {
      return res.status(400).json({ error: 'Pickup and destination are required.' });
    }

    if (fareReceived === undefined || fareReceived === null || isNaN(Number(fareReceived))) {
      return res.status(400).json({ error: 'Valid fare amount is required.' });
    }

    const fare = Number(fareReceived);
    const distance = Number(distanceKm || 0);
    const toll = Number(tollCharges || 0);
    const comm = Number(commission || 0);
    const other = Number(otherTripExpense || 0);

    const netProfit = fare - (toll + comm + other);

    const newTrip: Trip = {
      id: 'trip_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      userId,
      pickup: pickup.trim(),
      destination: destination.trim(),
      tripDate: tripDate || new Date().toISOString().split('T')[0],
      tripTime: tripTime || new Date().toTimeString().substring(0, 5),
      distanceKm: distance,
      fareReceived: fare,
      tollCharges: toll,
      commission: comm,
      otherTripExpense: other,
      notes: notes ? notes.trim() : '',
      paymentMode: paymentMode || 'cash',
      netProfit,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const created = await createTrip(newTrip);
    return res.status(201).json({
      message: 'Trip recorded successfully!',
      trip: created
    });
  } catch (err: any) {
    console.error('Create trip error:', err);
    return res.status(500).json({ error: 'Failed to create trip: ' + err.message });
  }
});

// PUT /api/trips/:id - Update an existing trip
router.put('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id } = req.params;
    const {
      pickup,
      destination,
      tripDate,
      tripTime,
      distanceKm,
      fareReceived,
      tollCharges,
      commission,
      otherTripExpense,
      notes,
      paymentMode
    } = req.body;

    const updates: Partial<Trip> = {};
    if (pickup !== undefined) updates.pickup = pickup.trim();
    if (destination !== undefined) updates.destination = destination.trim();
    if (tripDate !== undefined) updates.tripDate = tripDate;
    if (tripTime !== undefined) updates.tripTime = tripTime;
    if (distanceKm !== undefined) updates.distanceKm = Number(distanceKm);
    if (paymentMode !== undefined) updates.paymentMode = paymentMode;
    if (notes !== undefined) updates.notes = notes.trim();

    if (fareReceived !== undefined || tollCharges !== undefined || commission !== undefined || otherTripExpense !== undefined) {
      const fare = Number(fareReceived ?? 0);
      const toll = Number(tollCharges ?? 0);
      const comm = Number(commission ?? 0);
      const other = Number(otherTripExpense ?? 0);
      updates.fareReceived = fare;
      updates.tollCharges = toll;
      updates.commission = comm;
      updates.otherTripExpense = other;
      updates.netProfit = fare - (toll + comm + other);
    }

    const updated = await updateTrip(id, userId, updates);
    if (!updated) {
      return res.status(404).json({ error: 'Trip not found or unauthorized.' });
    }

    return res.json({
      message: 'Trip updated successfully!',
      trip: updated
    });
  } catch (err: any) {
    console.error('Update trip error:', err);
    return res.status(500).json({ error: 'Failed to update trip: ' + err.message });
  }
});

// DELETE /api/trips/:id - Delete a trip
router.delete('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id } = req.params;

    const deleted = await deleteTrip(id, userId);
    if (!deleted) {
      return res.status(404).json({ error: 'Trip not found or unauthorized.' });
    }

    return res.json({ message: 'Trip deleted successfully.' });
  } catch (err: any) {
    console.error('Delete trip error:', err);
    return res.status(500).json({ error: 'Failed to delete trip: ' + err.message });
  }
});

export default router;
