import { Router, Response } from 'express';
import {
  findUserByEmail,
  findUserById,
  createUser,
  updateUser,
  User
} from '../db.js';
import {
  hashPassword,
  comparePassword,
  generateToken,
  authenticateToken,
  AuthRequest
} from '../auth.js';

const router = Router();

// In-memory reset tokens for password recovery: { token: { email, expires } }
const resetTokens: Record<string, { email: string; expires: number }> = {};

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, vehicleNumber, vehicleType, fuelType, city, currency } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const existing = await findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists. Please log in.' });
    }

    const passwordHash = await hashPassword(password);
    const userId = 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

    const newUser: User = {
      id: userId,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash,
      phone: phone?.trim() || '',
      vehicleNumber: vehicleNumber?.trim().toUpperCase() || '',
      vehicleType: vehicleType || 'sedan',
      fuelType: fuelType || 'cng',
      city: city?.trim() || 'New Delhi',
      currency: currency || '₹',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await createUser(newUser);

    const token = generateToken(newUser);
    const { passwordHash: _, ...userSafe } = newUser;

    return res.status(201).json({
      message: 'Driver registration successful! Welcome to TaxiSaathi.',
      token,
      user: userSafe
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Failed to register account: ' + err.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = await findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const isMatch = await comparePassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = generateToken(user);
    const { passwordHash: _, ...userSafe } = user;

    return res.json({
      message: 'Login successful! Welcome back, ' + user.name,
      token,
      user: userSafe
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Failed to log in: ' + err.message });
  }
});

// POST /api/auth/demo-login - Quick 1-click test driver account
router.post('/demo-login', async (req, res) => {
  try {
    const demoEmail = 'rajesh.kumar@taxisaathi.in';
    const user = await findUserByEmail(demoEmail);

    if (!user) {
      return res.status(404).json({ error: 'Demo account not initialized yet. Please wait a moment.' });
    }

    const token = generateToken(user);
    const { passwordHash: _, ...userSafe } = user;

    return res.json({
      message: 'Logged in as Demo Driver Rajesh Kumar!',
      token,
      user: userSafe
    });
  } catch (err: any) {
    console.error('Demo login error:', err);
    return res.status(500).json({ error: 'Demo login failed: ' + err.message });
  }
});

// GET /api/auth/me
router.get('/me', authenticateToken, async (req: AuthRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  const { passwordHash: _, ...userSafe } = req.user;
  return res.json({ user: userSafe });
});

// PUT /api/auth/profile
router.put('/profile', authenticateToken, async (req: AuthRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

  try {
    const { name, phone, vehicleNumber, vehicleType, fuelType, city, currency } = req.body;
    const updates: Partial<User> = {};

    if (name) updates.name = name.trim();
    if (phone !== undefined) updates.phone = phone.trim();
    if (vehicleNumber !== undefined) updates.vehicleNumber = vehicleNumber.trim().toUpperCase();
    if (vehicleType) updates.vehicleType = vehicleType;
    if (fuelType) updates.fuelType = fuelType;
    if (city !== undefined) updates.city = city.trim();
    if (currency) updates.currency = currency;

    const updated = await updateUser(req.user.id, updates);
    if (!updated) return res.status(404).json({ error: 'Driver profile not found' });

    const { passwordHash: _, ...userSafe } = updated;
    return res.json({ message: 'Profile updated successfully', user: userSafe });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to update profile: ' + err.message });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required.' });

    const user = await findUserByEmail(email);
    if (!user) {
      // Don't leak user existence in production, but confirm email submitted
      return res.json({
        message: 'If an account exists with this email, a password reset link has been dispatched.',
        resetCode: '123456' // friendly simulation code for testing
      });
    }

    const resetToken = 'rst_' + Math.random().toString(36).substring(2, 10);
    resetTokens[resetToken] = {
      email: user.email,
      expires: Date.now() + 30 * 60 * 1000 // 30 minutes
    };

    return res.json({
      message: 'Password reset request generated successfully!',
      resetToken,
      resetCode: '889922'
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Forgot password failed: ' + err.message });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', async (req, res) => {
  try {
    const { email, newPassword, resetToken, resetCode } = req.body;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long.' });
    }

    // Allow reset with either token or valid simulation code
    let targetEmail = email;
    if (resetToken && resetTokens[resetToken]) {
      if (Date.now() > resetTokens[resetToken].expires) {
        return res.status(400).json({ error: 'Reset token has expired. Please request a new one.' });
      }
      targetEmail = resetTokens[resetToken].email;
      delete resetTokens[resetToken];
    }

    if (!targetEmail) {
      return res.status(400).json({ error: 'Email or reset verification is required.' });
    }

    const user = await findUserByEmail(targetEmail);
    if (!user) {
      return res.status(404).json({ error: 'User account not found.' });
    }

    const newHash = await hashPassword(newPassword);
    await updateUser(user.id, { passwordHash: newHash });

    return res.json({ message: 'Password updated successfully! You can now log in with your new password.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to reset password: ' + err.message });
  }
});

export default router;
