import { Router, Response } from 'express';
import {
  getExpensesByUserId,
  createExpense,
  updateExpense,
  deleteExpense,
  Expense
} from '../db.js';
import { authenticateToken, AuthRequest } from '../auth.js';

const router = Router();

router.use(authenticateToken);

// GET /api/expenses - List user expenses with category & date filters
router.get('/', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { category, startDate, endDate } = req.query as {
      category?: string;
      startDate?: string;
      endDate?: string;
    };

    const expenses = await getExpensesByUserId(userId, {
      category,
      startDate,
      endDate
    });

    const totalAmount = expenses.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    const categoryTotals: Record<string, number> = {};
    expenses.forEach(e => {
      categoryTotals[e.category] = (categoryTotals[e.category] || 0) + Number(e.amount || 0);
    });

    return res.json({
      expenses,
      summary: {
        totalAmount,
        totalCount: expenses.length,
        categoryTotals
      }
    });
  } catch (err: any) {
    console.error('Fetch expenses error:', err);
    return res.status(500).json({ error: 'Failed to retrieve expenses: ' + err.message });
  }
});

// POST /api/expenses - Add an expense
router.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { category, amount, expenseDate, odometerReading, notes, receiptRef, paymentMode } = req.body;

    if (!category || amount === undefined || isNaN(Number(amount)) || Number(amount) < 0) {
      return res.status(400).json({ error: 'Category and a valid expense amount are required.' });
    }

    const newExpense: Expense = {
      id: 'exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      userId,
      category,
      amount: Number(amount),
      expenseDate: expenseDate || new Date().toISOString().split('T')[0],
      odometerReading: odometerReading ? Number(odometerReading) : undefined,
      notes: notes ? notes.trim() : '',
      receiptRef: receiptRef ? receiptRef.trim() : '',
      paymentMode: paymentMode || 'cash',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const created = await createExpense(newExpense);
    return res.status(201).json({
      message: 'Expense added successfully!',
      expense: created
    });
  } catch (err: any) {
    console.error('Create expense error:', err);
    return res.status(500).json({ error: 'Failed to create expense: ' + err.message });
  }
});

// PUT /api/expenses/:id - Update an expense
router.put('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id } = req.params;
    const { category, amount, expenseDate, odometerReading, notes, receiptRef, paymentMode } = req.body;

    const updates: Partial<Expense> = {};
    if (category) updates.category = category;
    if (amount !== undefined) updates.amount = Number(amount);
    if (expenseDate) updates.expenseDate = expenseDate;
    if (odometerReading !== undefined) updates.odometerReading = Number(odometerReading);
    if (notes !== undefined) updates.notes = notes.trim();
    if (receiptRef !== undefined) updates.receiptRef = receiptRef.trim();
    if (paymentMode) updates.paymentMode = paymentMode;

    const updated = await updateExpense(id, userId, updates);
    if (!updated) {
      return res.status(404).json({ error: 'Expense record not found.' });
    }

    return res.json({
      message: 'Expense record updated!',
      expense: updated
    });
  } catch (err: any) {
    console.error('Update expense error:', err);
    return res.status(500).json({ error: 'Failed to update expense: ' + err.message });
  }
});

// DELETE /api/expenses/:id - Delete an expense
router.delete('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id } = req.params;

    const deleted = await deleteExpense(id, userId);
    if (!deleted) {
      return res.status(404).json({ error: 'Expense record not found.' });
    }

    return res.json({ message: 'Expense deleted successfully.' });
  } catch (err: any) {
    console.error('Delete expense error:', err);
    return res.status(500).json({ error: 'Failed to delete expense: ' + err.message });
  }
});

export default router;
