import { Router, Response } from 'express';
import { getTripsByUserId, getExpensesByUserId } from '../db.js';
import { authenticateToken, AuthRequest } from '../auth.js';

const router = Router();
router.use(authenticateToken);

// GET /api/analytics/dashboard
router.get('/dashboard', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const trips = await getTripsByUserId(userId);
    const expenses = await getExpensesByUserId(userId);

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentMonthPrefix = todayStr.substring(0, 7); // YYYY-MM

    // All time totals
    const totalTrips = trips.length;
    const totalDistance = trips.reduce((sum, t) => sum + (Number(t.distanceKm) || 0), 0);
    const totalFareReceived = trips.reduce((sum, t) => sum + (Number(t.fareReceived) || 0), 0);
    const totalTripDeductions = trips.reduce(
      (sum, t) => sum + (Number(t.tollCharges) || 0) + (Number(t.commission) || 0) + (Number(t.otherTripExpense) || 0),
      0
    );
    const totalOperationalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const totalFuelExpenses = expenses
      .filter(e => e.category === 'fuel')
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

    // Total Net Profit = Total Fare - Trip Deductions - General Expenses
    const totalNetProfit = totalFareReceived - totalTripDeductions - totalOperationalExpenses;
    const profitMargin = totalFareReceived > 0 ? Math.round((totalNetProfit / totalFareReceived) * 100) : 0;

    // Today's stats
    const todayTrips = trips.filter(t => t.tripDate === todayStr);
    const todayFare = todayTrips.reduce((sum, t) => sum + (Number(t.fareReceived) || 0), 0);
    const todayTripDeductions = todayTrips.reduce(
      (sum, t) => sum + (Number(t.tollCharges) || 0) + (Number(t.commission) || 0) + (Number(t.otherTripExpense) || 0),
      0
    );
    const todayExpenses = expenses.filter(e => e.expenseDate === todayStr);
    const todayOperationalExpenses = todayExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const todayFuelExpense = todayExpenses
      .filter(e => e.category === 'fuel')
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const todayNetProfit = todayFare - todayTripDeductions - todayOperationalExpenses;
    const todayDistance = todayTrips.reduce((sum, t) => sum + (Number(t.distanceKm) || 0), 0);

    // Monthly stats
    const monthTrips = trips.filter(t => t.tripDate.startsWith(currentMonthPrefix));
    const monthFare = monthTrips.reduce((sum, t) => sum + (Number(t.fareReceived) || 0), 0);
    const monthTripDeductions = monthTrips.reduce(
      (sum, t) => sum + (Number(t.tollCharges) || 0) + (Number(t.commission) || 0) + (Number(t.otherTripExpense) || 0),
      0
    );
    const monthExpenses = expenses.filter(e => e.expenseDate.startsWith(currentMonthPrefix));
    const monthOperationalExpenses = monthExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const monthFuelExpense = monthExpenses
      .filter(e => e.category === 'fuel')
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const monthNetProfit = monthFare - monthTripDeductions - monthOperationalExpenses;
    const monthDistance = monthTrips.reduce((sum, t) => sum + (Number(t.distanceKm) || 0), 0);

    // Last 14 days time-series graph points
    const dailySeries: Array<{
      date: string;
      label: string;
      revenue: number;
      expenses: number;
      profit: number;
      tripsCount: number;
      distance: number;
    }> = [];

    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const dLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      const dayT = trips.filter(t => t.tripDate === dStr);
      const dayE = expenses.filter(e => e.expenseDate === dStr);

      const dFare = dayT.reduce((sum, t) => sum + (Number(t.fareReceived) || 0), 0);
      const dTripDed = dayT.reduce(
        (sum, t) => sum + (Number(t.tollCharges) || 0) + (Number(t.commission) || 0) + (Number(t.otherTripExpense) || 0),
        0
      );
      const dOpExp = dayE.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      const dTotalExp = dTripDed + dOpExp;
      const dProfit = dFare - dTotalExp;
      const dDist = dayT.reduce((sum, t) => sum + (Number(t.distanceKm) || 0), 0);

      dailySeries.push({
        date: dStr,
        label: dLabel,
        revenue: dFare,
        expenses: dTotalExp,
        profit: dProfit,
        tripsCount: dayT.length,
        distance: dDist
      });
    }

    // Expense breakdown by category
    const expenseBreakdown: Record<string, number> = {
      fuel: 0,
      maintenance: 0,
      insurance: 0,
      permits: 0,
      challan_parking: 0,
      other: 0
    };
    expenses.forEach(e => {
      const cat = e.category || 'other';
      expenseBreakdown[cat] = (expenseBreakdown[cat] || 0) + Number(e.amount || 0);
    });

    // Payment modes breakdown
    const paymentModes: Record<string, number> = {
      cash: 0,
      upi: 0,
      card: 0,
      wallet: 0,
      other: 0
    };
    trips.forEach(t => {
      const mode = t.paymentMode || 'cash';
      paymentModes[mode] = (paymentModes[mode] || 0) + Number(t.fareReceived || 0);
    });

    // Key Performance Indicators
    const avgFarePerKm = totalDistance > 0 ? Math.round((totalFareReceived / totalDistance) * 10) / 10 : 0;
    const avgEarningsPerTrip = totalTrips > 0 ? Math.round(totalFareReceived / totalTrips) : 0;
    const fuelCostPerKm = totalDistance > 0 ? Math.round((totalFuelExpenses / totalDistance) * 10) / 10 : 0;
    const netReturnPerKm = totalDistance > 0 ? Math.round((totalNetProfit / totalDistance) * 10) / 10 : 0;

    // Recent 6 trips
    const recentTrips = trips.slice(0, 6);

    return res.json({
      summary: {
        totalTrips,
        totalDistance: Math.round(totalDistance),
        totalFareReceived,
        totalOperationalExpenses,
        totalFuelExpenses,
        totalNetProfit,
        profitMargin,
        // Daily
        today: {
          trips: todayTrips.length,
          earnings: todayFare,
          netProfit: todayNetProfit,
          expenses: todayOperationalExpenses,
          fuelExpense: todayFuelExpense,
          distance: Math.round(todayDistance)
        },
        // Monthly
        month: {
          trips: monthTrips.length,
          earnings: monthFare,
          netProfit: monthNetProfit,
          expenses: monthOperationalExpenses,
          fuelExpense: monthFuelExpense,
          distance: Math.round(monthDistance)
        },
        // Unit economics
        kpis: {
          avgFarePerKm,
          avgEarningsPerTrip,
          fuelCostPerKm,
          netReturnPerKm
        }
      },
      dailySeries,
      expenseBreakdown,
      paymentModes,
      recentTrips
    });
  } catch (err: any) {
    console.error('Analytics dashboard error:', err);
    return res.status(500).json({ error: 'Failed to generate dashboard analytics: ' + err.message });
  }
});

export default router;
