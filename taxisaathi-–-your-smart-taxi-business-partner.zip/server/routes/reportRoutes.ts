import { Router, Response } from 'express';
import { getTripsByUserId, getExpensesByUserId, getDatabaseStatus } from '../db.js';
import { authenticateToken, AuthRequest } from '../auth.js';
import { MongoClient } from 'mongodb';

const router = Router();

// GET /api/database/status (Public or protected check for database mode)
router.get('/status', (req, res) => {
  return res.json(getDatabaseStatus());
});

// POST /api/database/test-mongodb (Test a MongoDB connection string)
router.post('/test-mongodb', async (req, res) => {
  const { uri } = req.body;
  if (!uri || typeof uri !== 'string' || !uri.startsWith('mongodb')) {
    return res.status(400).json({ success: false, error: 'Please provide a valid MongoDB connection string starting with mongodb:// or mongodb+srv://' });
  }

  let testClient: MongoClient | null = null;
  try {
    testClient = new MongoClient(uri, { serverSelectionTimeoutMS: 4000 });
    await testClient.connect();
    await testClient.db('admin').command({ ping: 1 });
    await testClient.close();

    return res.json({
      success: true,
      message: 'MongoDB Atlas connection test succeeded! Database is reachable and ready.'
    });
  } catch (err: any) {
    if (testClient) {
      try { await testClient.close(); } catch {}
    }
    return res.status(400).json({
      success: false,
      error: 'Connection test failed: ' + err.message
    });
  }
});

// All report routes below require authentication
router.use(authenticateToken);

// GET /api/reports/summary - Generate comprehensive report ledger
router.get('/summary', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { period = 'month', startDate, endDate } = req.query as {
      period?: string;
      startDate?: string;
      endDate?: string;
    };

    const trips = await getTripsByUserId(userId, { startDate, endDate });
    const expenses = await getExpensesByUserId(userId, { startDate, endDate });

    const totalFare = trips.reduce((s, t) => s + (Number(t.fareReceived) || 0), 0);
    const totalTolls = trips.reduce((s, t) => s + (Number(t.tollCharges) || 0), 0);
    const totalCommissions = trips.reduce((s, t) => s + (Number(t.commission) || 0), 0);
    const totalOtherTripExp = trips.reduce((s, t) => s + (Number(t.otherTripExpense) || 0), 0);
    const totalDistance = trips.reduce((s, t) => s + (Number(t.distanceKm) || 0), 0);

    const totalExpenses = expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const fuelExpenses = expenses.filter(e => e.category === 'fuel').reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const maintenanceExpenses = expenses.filter(e => e.category === 'maintenance').reduce((s, e) => s + (Number(e.amount) || 0), 0);

    const grossTripProfit = totalFare - (totalTolls + totalCommissions + totalOtherTripExp);
    const netOverallProfit = grossTripProfit - totalExpenses;
    const profitMargin = totalFare > 0 ? Math.round((netOverallProfit / totalFare) * 100) : 0;

    return res.json({
      driver: {
        name: req.user!.name,
        vehicleNumber: req.user!.vehicleNumber,
        vehicleType: req.user!.vehicleType,
        fuelType: req.user!.fuelType,
        currency: req.user!.currency || '₹',
        city: req.user!.city
      },
      period,
      filter: { startDate, endDate },
      summary: {
        totalTrips: trips.length,
        totalDistance: Math.round(totalDistance),
        totalFare,
        totalTolls,
        totalCommissions,
        totalOtherTripExp,
        grossTripProfit,
        totalExpenses,
        fuelExpenses,
        maintenanceExpenses,
        netOverallProfit,
        profitMargin,
        avgFarePerKm: totalDistance > 0 ? (totalFare / totalDistance).toFixed(1) : '0',
        fuelCostPerKm: totalDistance > 0 ? (fuelExpenses / totalDistance).toFixed(1) : '0'
      },
      trips,
      expenses
    });
  } catch (err: any) {
    console.error('Report summary error:', err);
    return res.status(500).json({ error: 'Failed to generate report: ' + err.message });
  }
});

// GET /api/reports/export/csv - Download trips or expenses CSV
router.get('/export/csv', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { type = 'trips' } = req.query as { type?: string };

    if (type === 'expenses') {
      const expenses = await getExpensesByUserId(userId);
      let csv = 'ID,Date,Category,Amount,Odometer,Notes,PaymentMode,ReceiptRef\n';
      expenses.forEach(e => {
        csv += `"${e.id}","${e.expenseDate}","${e.category}","${e.amount}","${e.odometerReading || ''}","${(e.notes || '').replace(/"/g, '""')}","${e.paymentMode || ''}","${e.receiptRef || ''}"\n`;
      });
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="taxisaathi-expenses.csv"');
      return res.send(csv);
    } else {
      const trips = await getTripsByUserId(userId);
      let csv = 'ID,Date,Time,Pickup,Destination,DistanceKM,FareReceived,Toll,Commission,OtherExpense,NetProfit,PaymentMode,Notes\n';
      trips.forEach(t => {
        csv += `"${t.id}","${t.tripDate}","${t.tripTime}","${(t.pickup || '').replace(/"/g, '""')}","${(t.destination || '').replace(/"/g, '""')}","${t.distanceKm}","${t.fareReceived}","${t.tollCharges}","${t.commission}","${t.otherTripExpense}","${t.netProfit}","${t.paymentMode}","${(t.notes || '').replace(/"/g, '""')}"\n`;
      });
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="taxisaathi-trips.csv"');
      return res.send(csv);
    }
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to export CSV: ' + err.message });
  }
});

export default router;
